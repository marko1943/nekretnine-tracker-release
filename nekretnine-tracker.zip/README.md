# Nekretnine Tracker

[![CI](https://github.com/marko1943/nekretnine-tracker/actions/workflows/ci.yml/badge.svg)](https://github.com/marko1943/nekretnine-tracker/actions/workflows/ci.yml)
![coverage](docs/coverage.svg)

Chrome ekstenzija za čuvanje oglasa za nekretnine na jedno mesto — kao Pocket, ali za stanove.
Radi **univerzalno na bilo kom sajtu**; podaci se izvlače iz JSON-LD / Open Graph meta-podataka i
teksta stranice.

Podaci lokalno u **`chrome.storage.local`**. Opcioni cloud sync **direktno na Supabase** (Auth + REST, bez posrednog servera) — username/lozinka, bez Chrome Google sync-a. Setup: [docs/SERVER.md](docs/SERVER.md).

## Funkcije

- **Desni klik → "Sačuvaj ovu nekretninu"** na stranici oglasa
- **Desni klik na link → "Sačuvaj link nekretnine"** (fetch u pozadini)
- **Ikonica ekstenzije → "Sačuvaj trenutnu stranicu"** + brzi pregled; posle čuvanja prioritet, status, beleška
- **Lista** sa filterima, pretragom, sortiranjem i **grupisanjem po ključnim rečima**
- Ocena (1–5 zvezdica), prioritet, status (za obilazak / kontaktiran / obišao / odbačeno)
- Beleške po oglasu
- Pametno hvatanje cene:
  - ukupna cena + automatski €/m²
  - samo cena po m² → procena ukupne (`~`) — **samo za pojedinačan stan**
  - projekti novogradnje → **Po kvadraturi**, opseg m² (`44–60 m²`), €/m², bez lažne ukupne cene
  - "na kvadrat" sajtovi (npr. stan2) → prepoznaje da je cena zapravo €/m²
- Chip **Stan** / **Projekat** na kartici
- PDV status kad je jasan (`bez PDV` / `sa PDV`)
- U listi menjivo: cena, kvadratura (klik), ocena, prioritet, status, beleške, brisanje
- **Uvoz** — učitavanje JSON backup-a u listu
- **Cloud sync** — username + lozinka (direktno na Supabase); dugme **Nalog** u listi

## Testirani sajtovi

| Sajt | Napomena |
|------|----------|
| [4zida.rs](https://www.4zida.rs) | Stan + novogradnja projekat (`/novogradnja/…`) |
| [nekretnine.rs](https://www.nekretnine.rs) | JSON-LD + PDV |
| [cityexpert.rs](https://cityexpert.rs) | Projekti novogradnje (opseg m², €/m² od) |
| [stan2.rs](https://www.stan2.rs) | "Na kvadrat" cene, tabele |
| [distriktnekretnine.rs](https://distriktnekretnine.rs) | JSON-LD |
| [novogradnjanis.rs](https://novogradnjanis.rs) | schema.org microdata; cena u tabeli |
| [halooglasi.com](https://www.halooglasi.com) | JSON-LD + OG; Cloudflare (samo u browseru) |
| Ostali | Radi ako ima OG/JSON-LD; inače sačuva URL + ručni unos |

## Instalacija (developer mode)

1. Kloniraj repo i otvori `chrome://extensions`
2. Uključi **Developer mode** (gore desno)
3. **Load unpacked** → izaberi folder projekta
4. Zakači ikonicu kućice u toolbar (pin)

## Korišćenje

1. Otvori oglas na bilo kom sajtu
2. Desni klik → **Sačuvaj ovu nekretninu** (ili ikonica → **Sačuvaj trenutnu stranicu**)
3. Ikonica → **Otvori listu** za pregled, ocenu, filtere i beleške

Broj na ikonici = koliko oglasa imaš. Posle čuvanja kratko zasvetli `✓` (novo) ili `•` (ažurirano).

### Posle ažuriranja koda

1. `chrome://extensions` → **Reload** na kartici ekstenzije
2. **Osveži stranicu oglasa** (Cmd+R) — inače radi stara content skripta
3. **Ponovo sačuvaj** oglas da se podaci ažuriraju (ocena/beleške ostaju)

## Razvoj

```bash
npm test                    # unit + contract nad pravim uzorcima
npm run test:coverage       # testovi + izveštaj pokrivenosti (sa pragovima)
npm run coverage:badge      # osveži docs/coverage.svg (badge)
node tools/try-url.js URL   # brza provera izvlačenja na pravom linku
python3 tools/gen_icons.py    # regeneracija ikonica
```

Testovi su **dev alat** — trebaju samo kad menjaš `src/scrape.js` (npr. dodaješ novi sajt);
nisu deo same ekstenzije. Tok za novi sajt: `try-url.js` (provera uživo) → sačuvaj HTML
fixture + dodaj jedan red u `SAMPLES` (`tests/sites/samples.test.js`) → `npm test`.

**Pre-commit:** `npm test` mora da prođe pre svakog commit-a (git hook u `.githooks/`,
zakači se automatski na `npm install`). Preskoči jednom sa `git commit --no-verify`.

CI (GitHub Actions, `.github/workflows/ci.yml`) na svaki push na `main` i svaki PR
pokreće testove i izveštaj pokrivenosti. Coverage tabela se vidi u "Summary" pregleda
akcije, a `lcov.info` se čuva kao artifact. Pragovi (line 85% / branch 80% / funcs 80%)
ruše build ako pokrivenost `src/` padne ispod.

**Coverage badge** je self-hosted (`docs/coverage.svg`) — bez eksternog servisa. CI ga
na push na `main` regeneriše i commit-uje ako se procenat promenio; lokalno ga osvežiš
sa `npm run coverage:badge`.

Detaljnije: [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md) · Plan: [docs/BACKLOG.md](docs/BACKLOG.md) · Handoff: [docs/HANDOFF.md](docs/HANDOFF.md) · [CHANGELOG](docs/CHANGELOG.md) · [Store listing](docs/STORE_LISTING.md)

## Struktura

```
manifest.json          MV3 konfiguracija
popup.html / list.html UI
src/
  scrape.js            izvlačenje podataka (parseHtml + scrapeDocument)
  storage.js           local cache + cloud sync
  api.js               direktan Supabase klijent (Auth + REST)
  api-config.js        javni Supabase URL + publishable ključ
  sync-merge.js        merge local ↔ remote
  background.js        service worker, meni, čuvanje
  content.js           poruke sa otvorene stranice
  popup.js / list.js   UI logika
  options.js           login / sync (stranica „Nalog“)
server/                Cloudflare Worker (staro, van upotrebe — vidi docs/SERVER.md)
tests/
  scrape.test.js       univerzalni unit testovi (sintetički HTML)
  sites/samples.test.js contract: svi pravi fixture-i → pun rezultat
  fixtures/            pravi HTML uzorci po sajtu
tools/                 try-url.js, gen_icons.py
docs/                  dokumentacija za razvoj
```

## Privatnost

Podrazumevano lokalno. Cloud: oglasi idu direktno u Supabase (RLS po nalogu), bez posrednog servera. Nema analitike. [docs/PRIVACY.md](docs/PRIVACY.md).

## Chrome Web Store

Trenutna verzija: **1.3.0**. Javni ZIP: [nekretnine-tracker-release](https://github.com/marko1943/nekretnine-tracker-release). Chrome Web Store (unlisted) — u toku. Listing tekst: [docs/STORE_LISTING.md](docs/STORE_LISTING.md).

**Privacy policy URL (javni repo):**

`https://github.com/marko1943/nekretnine-tracker-release/blob/main/PRIVACY.md`

Setup automatskog publish-a: [docs/PUBLIC_RELEASE.md](docs/PUBLIC_RELEASE.md)

**Build paketa:**

```bash
zip -r nekretnine-tracker.zip . \
  -x "*.git*" -x "tests/*" -x "tools/*" -x "docs/*" -x "node_modules/*" \
  -x "server/*" -x "supabase/*"
```

Posle odobrenja, Store URL ide ovde.

## Licenca

Privatni projekat — za ličnu upotrebu.
