// Direktan Supabase klijent (Auth + REST). Bez Cloudflare Workera.
(function (global) {
  "use strict";

  function promisifyGet(keys) {
    return new Promise(function (resolve) {
      chrome.storage.local.get(keys, resolve);
    });
  }

  function promisifySet(obj) {
    return new Promise(function (resolve, reject) {
      chrome.storage.local.set(obj, function () {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve();
      });
    });
  }

  function promisifyRemove(keys) {
    return new Promise(function (resolve) {
      chrome.storage.local.remove(keys, resolve);
    });
  }

  function normalizeUrl(url) {
    return String(url || "").trim().replace(/\/+$/, "");
  }

  function bakedConfig() {
    var baked = global.NTApiConfig || {};
    return {
      supabaseUrl: normalizeUrl(baked.supabaseUrl),
      supabaseKey: String(baked.supabaseKey || "").trim()
    };
  }

  function getConfig() {
    return promisifyGet(["api_session", "sb_session"]).then(function (res) {
      var baked = bakedConfig();
      var session = res.api_session || res.sb_session || null;
      return {
        supabaseUrl: baked.supabaseUrl,
        supabaseKey: baked.supabaseKey,
        session: session
      };
    });
  }

  function saveSession(session) {
    if (!session) {
      return promisifyRemove(["api_session", "sb_session"]);
    }
    return promisifySet({ api_session: session }).then(function () {
      return promisifyRemove(["sb_session"]);
    });
  }

  function isConfigured(cfg) {
    return !!(cfg && cfg.supabaseUrl && cfg.supabaseKey);
  }

  function isLoggedIn(cfg) {
    return isConfigured(cfg) && !!(cfg.session && cfg.session.access_token);
  }

  function parseJsonSafe(text) {
    try {
      return text ? JSON.parse(text) : null;
    } catch (e) {
      return null;
    }
  }

  function toAuthEmail(username) {
    var u = String(username || "").trim();
    if (!u) return "";
    if (u.indexOf("@") !== -1) return u;
    var safe = u.toLowerCase().replace(/[^a-z0-9._-]+/g, "");
    return safe ? safe + "@nekretnine.local" : "";
  }

  function displayName(username, user) {
    if (username) return String(username).trim();
    var meta = user && user.user_metadata && user.user_metadata.username;
    if (meta) return meta;
    var email = user && user.email ? user.email : "";
    if (email.slice(-17) === "@nekretnine.local") return email.split("@")[0];
    return email;
  }

  function sessionPayload(data, username) {
    if (!data || !data.access_token) return null;
    var user = data.user || null;
    return {
      access_token: data.access_token,
      refresh_token: data.refresh_token || "",
      expires_at: data.expires_at || Math.floor(Date.now() / 1000) + (data.expires_in || 3600),
      user: user,
      username: displayName(username, user)
    };
  }

  function sbHeaders(cfg, accessToken) {
    return {
      apikey: cfg.supabaseKey,
      "Content-Type": "application/json",
      Authorization: "Bearer " + (accessToken || cfg.supabaseKey)
    };
  }

  function sbErrorMessage(data, fallback) {
    if (!data) return fallback;
    return data.error_description || data.msg || data.message || data.error || fallback;
  }

  function sbFetch(cfg, path, options) {
    options = options || {};
    return fetch(cfg.supabaseUrl + path, {
      method: options.method || "GET",
      headers: sbHeaders(cfg, options.accessToken),
      body: options.body != null ? JSON.stringify(options.body) : undefined
    }).then(function (res) {
      return res.text().then(function (text) {
        var data = parseJsonSafe(text);
        if (!res.ok) {
          var msg = sbErrorMessage(data, text || ("HTTP " + res.status));
          var e = new Error(msg);
          e.status = res.status;
          e.data = data;
          throw e;
        }
        return data;
      });
    });
  }

  function refreshIfNeeded(cfg) {
    if (!isLoggedIn(cfg)) return Promise.resolve(cfg);
    var expiresAt = Number(cfg.session.expires_at || 0);
    var now = Math.floor(Date.now() / 1000);
    if (expiresAt && expiresAt - 60 > now) return Promise.resolve(cfg);
    if (!cfg.session.refresh_token) return Promise.resolve(cfg);

    return sbFetch(cfg, "/auth/v1/token?grant_type=refresh_token", {
      method: "POST",
      body: { refresh_token: cfg.session.refresh_token }
    }).then(function (data) {
      var session = sessionPayload(data, cfg.session.username);
      if (!session) return cfg;
      if (!session.username && cfg.session.username) session.username = cfg.session.username;
      return saveSession(session).then(function () {
        cfg.session = session;
        return cfg;
      });
    }).catch(function () {
      // Istekao token i refresh nije uspeo — obriši sesiju da korisnik zna da se ponovo uloguje.
      if (expiresAt && expiresAt <= now) {
        return saveSession(null).then(function () {
          cfg.session = null;
          return cfg;
        });
      }
      return cfg;
    });
  }

  function withClient(fn) {
    return getConfig().then(function (cfg) {
      if (!isConfigured(cfg)) {
        var err = new Error("Supabase nije podešen (src/api-config.js)");
        err.code = "not_configured";
        throw err;
      }
      return refreshIfNeeded(cfg).then(fn);
    });
  }

  function signIn(username, password) {
    return getConfig().then(function (cfg) {
      if (!isConfigured(cfg)) {
        var err = new Error("Supabase nije podešen (src/api-config.js)");
        err.code = "not_configured";
        throw err;
      }
      var email = toAuthEmail(username);
      if (!email || !password) throw new Error("Username i lozinka su obavezni");
      return sbFetch(cfg, "/auth/v1/token?grant_type=password", {
        method: "POST",
        body: { email: email, password: String(password) }
      }).then(function (data) {
        var session = sessionPayload(data, username);
        if (!session) throw new Error("Nema sesije");
        return saveSession(session).then(function () {
          return session;
        });
      });
    });
  }

  function signUp(username, password) {
    return getConfig().then(function (cfg) {
      if (!isConfigured(cfg)) {
        var err = new Error("Supabase nije podešen (src/api-config.js)");
        err.code = "not_configured";
        throw err;
      }
      var email = toAuthEmail(username);
      if (!email || !password) throw new Error("Username i lozinka su obavezni");
      return sbFetch(cfg, "/auth/v1/signup", {
        method: "POST",
        body: {
          email: email,
          password: String(password),
          data: { username: String(username).trim() }
        }
      }).then(function (data) {
        var session = sessionPayload(data, username);
        if (!session) return { session: null, needsConfirm: true };
        return saveSession(session).then(function () {
          return { session: session, needsConfirm: false };
        });
      });
    });
  }

  function signOut() {
    return getConfig().then(function (cfg) {
      if (isLoggedIn(cfg)) {
        return sbFetch(cfg, "/auth/v1/logout", {
          method: "POST",
          accessToken: cfg.session.access_token,
          body: {}
        }).catch(function () {
          /* ignore */
        }).then(function () {
          return saveSession(null);
        });
      }
      return saveSession(null);
    });
  }

  function fetchListings() {
    return withClient(function (cfg) {
      if (!isLoggedIn(cfg)) {
        var err = new Error("Nisi ulogovan");
        err.code = "not_logged_in";
        throw err;
      }
      return sbFetch(
        cfg,
        "/rest/v1/listings?select=id,payload,updated_at,deleted&order=updated_at.asc",
        { accessToken: cfg.session.access_token }
      ).then(function (data) {
        return data || [];
      });
    });
  }

  function upsertRows(rows) {
    if (!rows || !rows.length) return Promise.resolve();
    return withClient(function (cfg) {
      if (!isLoggedIn(cfg)) {
        var err = new Error("Nisi ulogovan");
        err.code = "not_logged_in";
        throw err;
      }
      return sbFetch(cfg, "/auth/v1/user", {
        method: "GET",
        accessToken: cfg.session.access_token
      }).then(function (user) {
        if (!user || !user.id) throw new Error("Sesija nije važeća");
        var payload = rows.map(function (r) {
          return {
            user_id: user.id,
            id: r.id,
            payload: r.payload,
            updated_at: r.updated_at,
            deleted: !!r.deleted
          };
        });
        return fetch(
          cfg.supabaseUrl + "/rest/v1/listings?on_conflict=user_id,id",
          {
            method: "POST",
            headers: Object.assign({}, sbHeaders(cfg, cfg.session.access_token), {
              Prefer: "resolution=merge-duplicates,return=minimal"
            }),
            body: JSON.stringify(payload)
          }
        ).then(function (res) {
          return res.text().then(function (text) {
            if (!res.ok) {
              var data = parseJsonSafe(text);
              throw new Error(sbErrorMessage(data, text || "Upis nije uspeo"));
            }
          });
        });
      });
    });
  }

  function getStatus() {
    return getConfig().then(function (cfg) {
      var session = cfg.session;
      return {
        configured: isConfigured(cfg),
        loggedIn: isLoggedIn(cfg),
        username: session && session.username
          ? session.username
          : (session && session.user && session.user.email
            ? session.user.email.split("@")[0]
            : ""),
        email: session && session.user && session.user.email ? session.user.email : "",
        url: cfg.supabaseUrl || ""
      };
    });
  }

  var api = {
    getConfig: getConfig,
    getStatus: getStatus,
    signIn: signIn,
    signUp: signUp,
    signOut: signOut,
    fetchListings: fetchListings,
    upsertRows: upsertRows,
    isConfigured: isConfigured,
    isLoggedIn: isLoggedIn
  };

  global.NTApi = api;
  global.NTSupabase = api;
})(typeof self !== "undefined" ? self : window);
