// Klijent ka našem API-ju (Worker). Bez Supabase ključeva u ekstenziji.
(function (global) {
  "use strict";

  function promisifyGet(keys) {
    return new Promise(function (resolve) {
      chrome.storage.local.get(keys, resolve);
    });
  }

  function promisifySet(obj) {
    return new Promise(function (resolve, reject) {
      chrome.storage.local.set(obj, function () {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve();
      });
    });
  }

  function promisifyRemove(keys) {
    return new Promise(function (resolve) {
      chrome.storage.local.remove(keys, resolve);
    });
  }

  function normalizeUrl(url) {
    return String(url || "").trim().replace(/\/+$/, "");
  }

  function bakedApiUrl() {
    var baked = global.NTApiConfig || {};
    return normalizeUrl(baked.apiUrl);
  }

  function getConfig() {
    return promisifyGet(["api_url", "api_session", "sb_session"]).then(function (res) {
      // sb_session = legacy iz direktnog Supabase klijenta
      var session = res.api_session || res.sb_session || null;
      return {
        apiUrl: normalizeUrl(res.api_url) || bakedApiUrl(),
        session: session
      };
    });
  }

  function saveConfig(apiUrl) {
    return promisifySet({ api_url: normalizeUrl(apiUrl) });
  }

  function saveSession(session) {
    if (!session) {
      return promisifyRemove(["api_session", "sb_session"]);
    }
    return promisifySet({ api_session: session }).then(function () {
      return promisifyRemove(["sb_session"]);
    });
  }

  function isConfigured(cfg) {
    return !!(cfg && cfg.apiUrl);
  }

  function isLoggedIn(cfg) {
    return isConfigured(cfg) && !!(cfg.session && cfg.session.access_token);
  }

  function parseJsonSafe(text) {
    try {
      return text ? JSON.parse(text) : null;
    } catch (e) {
      return null;
    }
  }

  function apiRequest(cfg, path, options) {
    options = options || {};
    var headers = { "Content-Type": "application/json" };
    if (options.auth !== false && cfg.session && cfg.session.access_token) {
      headers.Authorization = "Bearer " + cfg.session.access_token;
    }
    return fetch(cfg.apiUrl + path, {
      method: options.method || "GET",
      headers: headers,
      body: options.body != null ? JSON.stringify(options.body) : undefined
    }).then(function (res) {
      return res.text().then(function (text) {
        var data = parseJsonSafe(text);
        if (!res.ok) {
          var msg =
            (data && (data.error || data.message)) ||
            text ||
            ("HTTP " + res.status);
          var e = new Error(msg);
          e.status = res.status;
          e.code = data && data.code;
          e.data = data;
          throw e;
        }
        return data;
      });
    });
  }

  function refreshIfNeeded(cfg) {
    if (!isLoggedIn(cfg)) return Promise.resolve(cfg);
    var expiresAt = Number(cfg.session.expires_at || 0);
    var now = Math.floor(Date.now() / 1000);
    if (expiresAt && expiresAt - 60 > now) return Promise.resolve(cfg);
    if (!cfg.session.refresh_token) return Promise.resolve(cfg);

    return apiRequest(cfg, "/auth/refresh", {
      method: "POST",
      auth: false,
      body: { refresh_token: cfg.session.refresh_token }
    }).then(function (data) {
      var session = data && data.session;
      if (!session) return cfg;
      if (!session.username && cfg.session.username) session.username = cfg.session.username;
      if (!session.user && cfg.session.user) session.user = cfg.session.user;
      return saveSession(session).then(function () {
        cfg.session = session;
        return cfg;
      });
    }).catch(function () {
      return cfg;
    });
  }

  function withClient(fn) {
    return getConfig().then(function (cfg) {
      if (!isConfigured(cfg)) {
        var err = new Error("API nije podešen (src/api-config.js)");
        err.code = "not_configured";
        throw err;
      }
      return refreshIfNeeded(cfg).then(fn);
    });
  }

  function signIn(username, password) {
    return getConfig().then(function (cfg) {
      if (!isConfigured(cfg)) {
        var err = new Error("API nije podešen (src/api-config.js)");
        err.code = "not_configured";
        throw err;
      }
      return apiRequest(cfg, "/auth/login", {
        method: "POST",
        auth: false,
        body: { username: String(username || "").trim(), password: String(password || "") }
      }).then(function (data) {
        var session = data && data.session;
        if (!session) throw new Error("Nema sesije");
        return saveSession(session).then(function () {
          return session;
        });
      });
    });
  }

  function signUp(username, password) {
    return getConfig().then(function (cfg) {
      if (!isConfigured(cfg)) {
        var err = new Error("API nije podešen (src/api-config.js)");
        err.code = "not_configured";
        throw err;
      }
      return apiRequest(cfg, "/auth/register", {
        method: "POST",
        auth: false,
        body: { username: String(username || "").trim(), password: String(password || "") }
      }).then(function (data) {
        if (data && data.needsConfirm) {
          return { session: null, needsConfirm: true };
        }
        var session = data && data.session;
        if (!session) return { session: null, needsConfirm: true };
        return saveSession(session).then(function () {
          return { session: session, needsConfirm: false };
        });
      });
    });
  }

  function signOut() {
    return getConfig().then(function (cfg) {
      if (isLoggedIn(cfg)) {
        return apiRequest(cfg, "/auth/logout", { method: "POST", body: {} }).catch(function () {
          /* ignore */
        }).then(function () {
          return saveSession(null);
        });
      }
      return saveSession(null);
    });
  }

  function fetchListings() {
    return withClient(function (cfg) {
      if (!isLoggedIn(cfg)) {
        var err = new Error("Nisi ulogovan");
        err.code = "not_logged_in";
        throw err;
      }
      return apiRequest(cfg, "/listings", { method: "GET" }).then(function (data) {
        return (data && data.rows) || [];
      });
    });
  }

  function upsertRows(rows) {
    if (!rows || !rows.length) return Promise.resolve();
    return withClient(function (cfg) {
      if (!isLoggedIn(cfg)) {
        var err = new Error("Nisi ulogovan");
        err.code = "not_logged_in";
        throw err;
      }
      return apiRequest(cfg, "/listings/upsert", {
        method: "POST",
        body: { rows: rows }
      });
    });
  }

  function getStatus() {
    return getConfig().then(function (cfg) {
      var session = cfg.session;
      return {
        configured: isConfigured(cfg),
        loggedIn: isLoggedIn(cfg),
        username: session && session.username
          ? session.username
          : (session && session.user && session.user.email
            ? session.user.email.split("@")[0]
            : ""),
        email: session && session.user && session.user.email ? session.user.email : "",
        url: cfg.apiUrl || ""
      };
    });
  }

  // Isti površinski API kao stari NTSupabase — manje churn-a u storage/UI.
  var api = {
    getConfig: getConfig,
    saveConfig: saveConfig,
    getStatus: getStatus,
    signIn: signIn,
    signUp: signUp,
    signOut: signOut,
    fetchListings: fetchListings,
    upsertRows: upsertRows,
    isConfigured: isConfigured,
    isLoggedIn: isLoggedIn
  };

  global.NTApi = api;
  global.NTSupabase = api;
})(typeof self !== "undefined" ? self : window);
