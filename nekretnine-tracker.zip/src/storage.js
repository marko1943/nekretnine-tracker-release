// Lokalni cache (chrome.storage.local) + opciono cloud sync (NTApi → Worker).
// Migracija: stari chrome.storage.sync → local (jednom).
(function (global) {
  "use strict";

  var STORE_INDEX = "listings_index";
  var STORE_PREFIX = "listing:";
  var MIGRATION_KEY = "storage_local_v2";
  var LEGACY_LOCAL_KEY = "listings";
  var SYNC_META_KEY = "sb_last_sync_at";

  var migrationPromise = null;
  var syncInFlight = null;

  function listingKey(id) {
    return STORE_PREFIX + id;
  }

  function promisify(fn) {
    return new Promise(function (resolve, reject) {
      try {
        fn(resolve, reject);
      } catch (e) {
        reject(e);
      }
    });
  }

  function localGet(keys) {
    return promisify(function (resolve) {
      chrome.storage.local.get(keys, resolve);
    });
  }

  function localSet(obj) {
    return promisify(function (resolve, reject) {
      chrome.storage.local.set(obj, function () {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve();
      });
    });
  }

  function localRemove(keys) {
    return promisify(function (resolve) {
      chrome.storage.local.remove(keys, resolve);
    });
  }

  function syncGet(keys) {
    return promisify(function (resolve) {
      if (!chrome.storage.sync) {
        resolve({});
        return;
      }
      chrome.storage.sync.get(keys, resolve);
    });
  }

  function readListingsMap() {
    return localGet(STORE_INDEX).then(function (res) {
      var ids = res[STORE_INDEX] || [];
      if (!ids.length) return {};
      return localGet(ids.map(listingKey)).then(function (items) {
        var map = {};
        ids.forEach(function (id) {
          var rec = items[listingKey(id)];
          if (rec) map[id] = rec;
        });
        return map;
      });
    });
  }

  function writeListingsMap(map) {
    return localGet(STORE_INDEX).then(function (res) {
      var oldIds = res[STORE_INDEX] || [];
      var newIds = Object.keys(map);
      var toSet = {};
      toSet[STORE_INDEX] = newIds;
      newIds.forEach(function (id) {
        toSet[listingKey(id)] = map[id];
      });
      var toRemove = oldIds
        .filter(function (id) { return !map[id]; })
        .map(listingKey);
      return localSet(toSet).then(function () {
        if (!toRemove.length) return;
        return localRemove(toRemove);
      });
    });
  }

  function readSyncListingsMap() {
    return syncGet(STORE_INDEX).then(function (res) {
      var ids = res[STORE_INDEX] || [];
      if (!ids.length) {
        return syncGet(LEGACY_LOCAL_KEY).then(function (legacyRes) {
          return legacyRes[LEGACY_LOCAL_KEY] || {};
        });
      }
      return syncGet(ids.map(listingKey)).then(function (items) {
        var map = {};
        ids.forEach(function (id) {
          var rec = items[listingKey(id)];
          if (rec) map[id] = rec;
        });
        return map;
      });
    });
  }

  function runMigration() {
    return localGet(MIGRATION_KEY).then(function (flagRes) {
      if (flagRes[MIGRATION_KEY]) return;

      return localGet([STORE_INDEX, LEGACY_LOCAL_KEY]).then(function (localRes) {
        var hasIndex = (localRes[STORE_INDEX] || []).length > 0;
        var legacyLocal = localRes[LEGACY_LOCAL_KEY] || {};
        var hasLegacyLocal = Object.keys(legacyLocal).length > 0;

        var seed = Promise.resolve({});

        if (hasIndex) {
          seed = Promise.resolve(null);
        } else if (hasLegacyLocal) {
          seed = Promise.resolve(legacyLocal);
        } else {
          seed = readSyncListingsMap();
        }

        return seed.then(function (fromElsewhere) {
          var chain = Promise.resolve();
          if (fromElsewhere && Object.keys(fromElsewhere).length) {
            chain = writeListingsMap(fromElsewhere);
          }
          return chain.then(function () {
            var flag = {};
            flag[MIGRATION_KEY] = true;
            return localSet(flag).then(function () {
              var cleanup = [];
              if (hasLegacyLocal) cleanup.push(localRemove([LEGACY_LOCAL_KEY]));
              return Promise.all(cleanup);
            });
          });
        });
      });
    });
  }

  function ensureMigrated() {
    if (!migrationPromise) migrationPromise = runMigration();
    return migrationPromise;
  }

  function cloudAvailable() {
    return typeof NTSupabase !== "undefined" && typeof NTSyncMerge !== "undefined";
  }

  function pushRecord(record, deleted) {
    if (!cloudAvailable()) return Promise.resolve();
    return NTSupabase.getStatus().then(function (st) {
      if (!st.loggedIn) return;
      var ts = NTSyncMerge.updatedAt(record) || Date.now();
      return NTSupabase.upsertRows([
        {
          id: record.id,
          payload: record,
          updated_at: ts,
          deleted: !!deleted
        }
      ]).catch(function (e) {
        console.warn("[NT] cloud push failed", e && e.message ? e.message : e);
      });
    });
  }

  function getAll() {
    return ensureMigrated().then(readListingsMap);
  }

  function setAll(map) {
    return ensureMigrated().then(function () {
      return writeListingsMap(map);
    });
  }

  function save(record) {
    return ensureMigrated().then(function () {
      return localGet(STORE_INDEX).then(function (res) {
        var ids = res[STORE_INDEX] || [];
        var toSet = {};
        toSet[listingKey(record.id)] = record;
        if (ids.indexOf(record.id) === -1) ids = ids.concat(record.id);
        toSet[STORE_INDEX] = ids;
        return localSet(toSet).then(function () {
          return pushRecord(record, false);
        });
      });
    });
  }

  function remove(id) {
    return ensureMigrated().then(function () {
      return localGet([STORE_INDEX, listingKey(id)]).then(function (res) {
        var existing = res[listingKey(id)] || { id: id, dateUpdated: Date.now() };
        existing.dateUpdated = Date.now();
        var ids = (res[STORE_INDEX] || []).filter(function (x) { return x !== id; });
        var idx = {};
        idx[STORE_INDEX] = ids;
        return localSet(idx)
          .then(function () {
            return localRemove([listingKey(id)]);
          })
          .then(function () {
            return pushRecord(existing, true);
          });
      });
    });
  }

  function isListingChange(changes) {
    if (changes[STORE_INDEX]) return true;
    return Object.keys(changes).some(function (k) {
      return k.indexOf(STORE_PREFIX) === 0;
    });
  }

  function syncNow() {
    if (!cloudAvailable()) {
      return Promise.reject(Object.assign(new Error("Cloud modul nije učitan"), { code: "no_cloud" }));
    }
    if (syncInFlight) return syncInFlight;

    syncInFlight = ensureMigrated()
      .then(function () {
        return NTSupabase.getStatus();
      })
      .then(function (st) {
        if (!st.configured) {
          var err = new Error("Supabase nije podešen");
          err.code = "not_configured";
          throw err;
        }
        if (!st.loggedIn) {
          var err2 = new Error("Nisi ulogovan");
          err2.code = "not_logged_in";
          throw err2;
        }
        return Promise.all([readListingsMap(), NTSupabase.fetchListings()]);
      })
      .then(function (pair) {
        var localMap = pair[0];
        var remoteRows = pair[1];
        var merged = NTSyncMerge.mergeMaps(localMap, remoteRows);
        var write = merged.changed ? writeListingsMap(merged.map) : Promise.resolve();
        var push = merged.push.length ? NTSupabase.upsertRows(merged.push) : Promise.resolve();
        return Promise.all([write, push]).then(function () {
          return localSet((function () {
            var o = {};
            o[SYNC_META_KEY] = Date.now();
            return o;
          })()).then(function () {
            return {
              count: Object.keys(merged.map).length,
              pushed: merged.push.length,
              changed: merged.changed
            };
          });
        });
      })
      .finally(function () {
        syncInFlight = null;
      });

    return syncInFlight;
  }

  function getSyncMeta() {
    return localGet(SYNC_META_KEY).then(function (res) {
      return { lastSyncAt: res[SYNC_META_KEY] || 0 };
    });
  }

  global.NTStorage = {
    getAll: getAll,
    setAll: setAll,
    save: save,
    remove: remove,
    isListingChange: isListingChange,
    syncNow: syncNow,
    getSyncMeta: getSyncMeta,
    storageArea: "local"
  };
})(typeof self !== "undefined" ? self : window);
