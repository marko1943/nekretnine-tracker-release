// chrome.storage.sync — jedan oglas po ključu (limit 8 KB/stavka, ~100 KB ukupno).
(function (global) {
  "use strict";

  var STORE_INDEX = "listings_index";
  var STORE_PREFIX = "listing:";
  var MIGRATION_KEY = "storage_sync_v1";
  var LEGACY_KEY = "listings";

  var migrationPromise = null;

  function listingKey(id) {
    return STORE_PREFIX + id;
  }

  function promisify(fn) {
    return new Promise(function (resolve, reject) {
      try {
        fn(resolve, reject);
      } catch (e) {
        reject(e);
      }
    });
  }

  function readListingsMap() {
    return promisify(function (resolve) {
      chrome.storage.sync.get(STORE_INDEX, function (res) {
        var ids = res[STORE_INDEX] || [];
        if (!ids.length) {
          resolve({});
          return;
        }
        var keys = ids.map(listingKey);
        chrome.storage.sync.get(keys, function (items) {
          var map = {};
          ids.forEach(function (id) {
            var rec = items[listingKey(id)];
            if (rec) map[id] = rec;
          });
          resolve(map);
        });
      });
    });
  }

  function writeListingsMap(map) {
    return promisify(function (resolve) {
      chrome.storage.sync.get(STORE_INDEX, function (res) {
        var oldIds = res[STORE_INDEX] || [];
        var newIds = Object.keys(map);
        var toSet = {};
        toSet[STORE_INDEX] = newIds;
        newIds.forEach(function (id) {
          toSet[listingKey(id)] = map[id];
        });
        var toRemove = oldIds
          .filter(function (id) { return !map[id]; })
          .map(listingKey);
        chrome.storage.sync.set(toSet, function () {
          if (!toRemove.length) {
            resolve();
            return;
          }
          chrome.storage.sync.remove(toRemove, resolve);
        });
      });
    });
  }

  function runMigration() {
    return promisify(function (resolve) {
      chrome.storage.sync.get(MIGRATION_KEY, function (syncRes) {
        if (syncRes[MIGRATION_KEY]) {
          resolve();
          return;
        }
        chrome.storage.local.get(LEGACY_KEY, function (localRes) {
          var legacy = localRes[LEGACY_KEY] || {};
          if (!Object.keys(legacy).length) {
            var flag = {};
            flag[MIGRATION_KEY] = true;
            chrome.storage.sync.set(flag, resolve);
            return;
          }
          writeListingsMap(legacy).then(function () {
            var flag = {};
            flag[MIGRATION_KEY] = true;
            chrome.storage.sync.set(flag, function () {
              chrome.storage.local.remove(LEGACY_KEY, resolve);
            });
          });
        });
      });
    });
  }

  function ensureMigrated() {
    if (!migrationPromise) migrationPromise = runMigration();
    return migrationPromise;
  }

  function getAll() {
    return ensureMigrated().then(readListingsMap);
  }

  function setAll(map) {
    return ensureMigrated().then(function () {
      return writeListingsMap(map);
    });
  }

  function save(record) {
    return ensureMigrated().then(function () {
      return promisify(function (resolve) {
        chrome.storage.sync.get(STORE_INDEX, function (res) {
          var ids = res[STORE_INDEX] || [];
          var toSet = {};
          toSet[listingKey(record.id)] = record;
          if (ids.indexOf(record.id) === -1) {
            ids = ids.concat(record.id);
            toSet[STORE_INDEX] = ids;
          }
          chrome.storage.sync.set(toSet, resolve);
        });
      });
    });
  }

  function remove(id) {
    return ensureMigrated().then(function () {
      return promisify(function (resolve) {
        chrome.storage.sync.get(STORE_INDEX, function (res) {
          var ids = (res[STORE_INDEX] || []).filter(function (x) { return x !== id; });
          var idx = {};
          idx[STORE_INDEX] = ids;
          chrome.storage.sync.set(idx, function () {
            chrome.storage.sync.remove(listingKey(id), resolve);
          });
        });
      });
    });
  }

  function isListingChange(changes) {
    if (changes[STORE_INDEX]) return true;
    return Object.keys(changes).some(function (k) {
      return k.indexOf(STORE_PREFIX) === 0;
    });
  }

  global.NTStorage = {
    getAll: getAll,
    setAll: setAll,
    save: save,
    remove: remove,
    isListingChange: isListingChange
  };
})(typeof self !== "undefined" ? self : window);
