// Listinzi u chrome.storage.sync (sinhronizacija preko Google naloga).
// Cloud sync (NTApi → Worker) opciono. Migracija: local → sync (jednom).
(function (global) {
  "use strict";

  var STORE_INDEX = "listings_index";
  var STORE_PREFIX = "listing:";
  var MIGRATION_KEY = "storage_local_v2";
  var LEGACY_LOCAL_KEY = "listings";
  var SYNC_META_KEY = "sb_last_sync_at";

  var migrationPromise = null;
  var syncInFlight = null;

  function listingKey(id) {
    return STORE_PREFIX + id;
  }

  function promisify(fn) {
    return new Promise(function (resolve, reject) {
      try {
        fn(resolve, reject);
      } catch (e) {
        reject(e);
      }
    });
  }

  var store = chrome.storage.sync || chrome.storage.local;

  function storeGet(keys) {
    return promisify(function (resolve) {
      store.get(keys, resolve);
    });
  }

  function storeSet(obj) {
    return promisify(function (resolve, reject) {
      store.set(obj, function () {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve();
      });
    });
  }

  function storeRemove(keys) {
    return promisify(function (resolve) {
      store.remove(keys, resolve);
    });
  }

  function localGet(keys) {
    return promisify(function (resolve) {
      chrome.storage.local.get(keys, resolve);
    });
  }

  function localSet(obj) {
    return promisify(function (resolve, reject) {
      chrome.storage.local.set(obj, function () {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve();
      });
    });
  }

  function localRemove(keys) {
    return promisify(function (resolve) {
      chrome.storage.local.remove(keys, resolve);
    });
  }

  function readListingsMap() {
    return storeGet(STORE_INDEX).then(function (res) {
      var ids = res[STORE_INDEX] || [];
      if (!ids.length) return {};
      return storeGet(ids.map(listingKey)).then(function (items) {
        var map = {};
        ids.forEach(function (id) {
          var rec = items[listingKey(id)];
          if (rec) map[id] = rec;
        });
        return map;
      });
    });
  }

  function writeListingsMap(map) {
    return storeGet(STORE_INDEX).then(function (res) {
      var oldIds = res[STORE_INDEX] || [];
      var newIds = Object.keys(map);
      var toSet = {};
      toSet[STORE_INDEX] = newIds;
      newIds.forEach(function (id) {
        toSet[listingKey(id)] = map[id];
      });
      var toRemove = oldIds
        .filter(function (id) { return !map[id]; })
        .map(listingKey);
      return storeSet(toSet).then(function () {
        if (!toRemove.length) return;
        return storeRemove(toRemove);
      });
    });
  }

  var MIGRATION_SYNC_KEY = "storage_sync_v3";

  function readLocalListingsMap() {
    return localGet(STORE_INDEX).then(function (res) {
      var ids = res[STORE_INDEX] || [];
      if (!ids.length) {
        return localGet(LEGACY_LOCAL_KEY).then(function (legacyRes) {
          return legacyRes[LEGACY_LOCAL_KEY] || {};
        });
      }
      return localGet(ids.map(listingKey)).then(function (items) {
        var map = {};
        ids.forEach(function (id) {
          var rec = items[listingKey(id)];
          if (rec) map[id] = rec;
        });
        return map;
      });
    });
  }

  function runMigration() {
    return storeGet(MIGRATION_SYNC_KEY).then(function (flagRes) {
      if (flagRes[MIGRATION_SYNC_KEY]) return;

      return readLocalListingsMap().then(function (localMap) {
        return storeGet(STORE_INDEX).then(function (syncRes) {
          var syncIds = syncRes[STORE_INDEX] || [];
          var hasSyncData = syncIds.length > 0;

          var chain = Promise.resolve();
          if (!hasSyncData && Object.keys(localMap).length) {
            chain = writeListingsMap(localMap);
          }
          return chain.then(function () {
            var flag = {};
            flag[MIGRATION_SYNC_KEY] = true;
            return storeSet(flag);
          });
        });
      });
    });
  }

  function ensureMigrated() {
    if (!migrationPromise) migrationPromise = runMigration();
    return migrationPromise;
  }

  function cloudAvailable() {
    return typeof NTSupabase !== "undefined" && typeof NTSyncMerge !== "undefined";
  }

  function pushRecord(record, deleted) {
    if (!cloudAvailable()) return Promise.resolve();
    return NTSupabase.getStatus().then(function (st) {
      if (!st.loggedIn) return;
      var ts = NTSyncMerge.updatedAt(record) || Date.now();
      return NTSupabase.upsertRows([
        {
          id: record.id,
          payload: record,
          updated_at: ts,
          deleted: !!deleted
        }
      ]).catch(function (e) {
        console.warn("[NT] cloud push failed", e && e.message ? e.message : e);
      });
    });
  }

  function getAll() {
    return ensureMigrated().then(readListingsMap);
  }

  function setAll(map) {
    return ensureMigrated().then(function () {
      return writeListingsMap(map);
    });
  }

  function save(record) {
    return ensureMigrated().then(function () {
      return storeGet(STORE_INDEX).then(function (res) {
        var ids = res[STORE_INDEX] || [];
        var toSet = {};
        toSet[listingKey(record.id)] = record;
        if (ids.indexOf(record.id) === -1) ids = ids.concat(record.id);
        toSet[STORE_INDEX] = ids;
        return storeSet(toSet).then(function () {
          return pushRecord(record, false);
        });
      });
    });
  }

  function remove(id) {
    return ensureMigrated().then(function () {
      return storeGet([STORE_INDEX, listingKey(id)]).then(function (res) {
        var existing = res[listingKey(id)] || { id: id, dateUpdated: Date.now() };
        existing.dateUpdated = Date.now();
        var ids = (res[STORE_INDEX] || []).filter(function (x) { return x !== id; });
        var idx = {};
        idx[STORE_INDEX] = ids;
        return storeSet(idx)
          .then(function () {
            return storeRemove([listingKey(id)]);
          })
          .then(function () {
            return pushRecord(existing, true);
          });
      });
    });
  }

  function isListingChange(changes) {
    if (changes[STORE_INDEX]) return true;
    return Object.keys(changes).some(function (k) {
      return k.indexOf(STORE_PREFIX) === 0;
    });
  }

  function syncNow() {
    if (!cloudAvailable()) {
      return Promise.reject(Object.assign(new Error("Cloud modul nije učitan"), { code: "no_cloud" }));
    }
    if (syncInFlight) return syncInFlight;

    syncInFlight = ensureMigrated()
      .then(function () {
        return NTSupabase.getStatus();
      })
      .then(function (st) {
        if (!st.configured) {
          var err = new Error("Supabase nije podešen");
          err.code = "not_configured";
          throw err;
        }
        if (!st.loggedIn) {
          var err2 = new Error("Nisi ulogovan");
          err2.code = "not_logged_in";
          throw err2;
        }
        return Promise.all([readListingsMap(), NTSupabase.fetchListings()]);
      })
      .then(function (pair) {
        var localMap = pair[0];
        var remoteRows = pair[1];
        var merged = NTSyncMerge.mergeMaps(localMap, remoteRows);
        var write = merged.changed ? writeListingsMap(merged.map) : Promise.resolve();
        var push = merged.push.length ? NTSupabase.upsertRows(merged.push) : Promise.resolve();
        return Promise.all([write, push]).then(function () {
          return localSet((function () {
            var o = {};
            o[SYNC_META_KEY] = Date.now();
            return o;
          })()).then(function () {
            return {
              count: Object.keys(merged.map).length,
              pushed: merged.push.length,
              changed: merged.changed
            };
          });
        });
      })
      .finally(function () {
        syncInFlight = null;
      });

    return syncInFlight;
  }

  function getSyncMeta() {
    return localGet(SYNC_META_KEY).then(function (res) {
      return { lastSyncAt: res[SYNC_META_KEY] || 0 };
    });
  }

  global.NTStorage = {
    getAll: getAll,
    setAll: setAll,
    save: save,
    remove: remove,
    isListingChange: isListingChange,
    syncNow: syncNow,
    getSyncMeta: getSyncMeta,
    storageArea: "sync"
  };
})(typeof self !== "undefined" ? self : window);
