// Listinzi u chrome.storage.local (cache). Izvor istine: Supabase.
// Migracija jednom: chrome.storage.sync / legacy local → local.
(function (global) {
  "use strict";

  var STORE_INDEX = "listings_index";
  var STORE_PREFIX = "listing:";
  var LEGACY_LOCAL_KEY = "listings";
  var SYNC_META_KEY = "sb_last_sync_at";
  var MIGRATION_KEY = "storage_local_v4";

  var migrationPromise = null;
  var syncInFlight = null;

  function listingKey(id) {
    return STORE_PREFIX + id;
  }

  function promisify(fn) {
    return new Promise(function (resolve, reject) {
      try {
        fn(resolve, reject);
      } catch (e) {
        reject(e);
      }
    });
  }

  var store = chrome.storage.local;

  function storeGet(keys) {
    return promisify(function (resolve) {
      store.get(keys, resolve);
    });
  }

  function storeSet(obj) {
    return promisify(function (resolve, reject) {
      store.set(obj, function () {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve();
      });
    });
  }

  function storeRemove(keys) {
    return promisify(function (resolve) {
      store.remove(keys, resolve);
    });
  }

  function mapFromAll(all) {
    var map = {};
    Object.keys(all || {}).forEach(function (k) {
      if (k.indexOf(STORE_PREFIX) === 0 && all[k]) {
        map[k.slice(STORE_PREFIX.length)] = all[k];
      }
    });
    return map;
  }

  function readListingsMap() {
    return storeGet(null).then(mapFromAll);
  }

  function writeListingsMap(map) {
    return storeGet(null).then(function (all) {
      var oldIds = all[STORE_INDEX] || [];
      var existingIds = Object.keys(mapFromAll(all));
      var newIds = Object.keys(map);
      var combinedIds = mergeIndex(mergeIndex(oldIds, existingIds), newIds);

      var toSet = {};
      toSet[STORE_INDEX] = combinedIds;
      newIds.forEach(function (id) {
        toSet[listingKey(id)] = map[id];
      });
      return storeSet(toSet);
    });
  }

  function readAreaListingsMap(area) {
    if (!area) return Promise.resolve({});
    return promisify(function (resolve) {
      area.get(null, resolve);
    }).then(function (all) {
      var map = mapFromAll(all);
      if (Object.keys(map).length) return map;
      var legacy = all[LEGACY_LOCAL_KEY];
      return legacy && typeof legacy === "object" ? legacy : {};
    });
  }

  function preferNewer(a, b) {
    var ta = (a && a.dateUpdated) || 0;
    var tb = (b && b.dateUpdated) || 0;
    return tb > ta ? b : a;
  }

  function mergeMaps(a, b) {
    var out = {};
    Object.keys(a || {}).forEach(function (id) { out[id] = a[id]; });
    Object.keys(b || {}).forEach(function (id) {
      out[id] = out[id] ? preferNewer(out[id], b[id]) : b[id];
    });
    return out;
  }

  function runMigration() {
    return storeGet(MIGRATION_KEY).then(function (flagRes) {
      if (flagRes[MIGRATION_KEY]) return;

      var syncArea = chrome.storage.sync;
      return Promise.all([
        readListingsMap(),
        readAreaListingsMap(syncArea)
      ]).then(function (pair) {
        var merged = mergeMaps(pair[0], pair[1]);
        var chain = Object.keys(merged).length
          ? writeListingsMap(merged)
          : Promise.resolve();
        return chain.then(function () {
          var flag = {};
          flag[MIGRATION_KEY] = true;
          return storeSet(flag);
        });
      });
    });
  }

  function ensureMigrated() {
    if (!migrationPromise) migrationPromise = runMigration();
    return migrationPromise;
  }

  function cloudAvailable() {
    return typeof NTSupabase !== "undefined" && typeof NTSyncMerge !== "undefined";
  }

  function pushRecord(record, deleted) {
    if (!cloudAvailable()) return Promise.resolve();
    return NTSupabase.getStatus().then(function (st) {
      if (!st.loggedIn) return;
      var ts = NTSyncMerge.updatedAt(record) || Date.now();
      return NTSupabase.upsertRows([
        {
          id: record.id,
          payload: record,
          updated_at: ts,
          deleted: !!deleted
        }
      ]).catch(function (e) {
        console.warn("[NT] cloud push failed", e && e.message ? e.message : e);
      });
    });
  }

  function getAll() {
    return ensureMigrated().then(readListingsMap);
  }

  function setAll(map) {
    return ensureMigrated().then(function () {
      return writeListingsMap(map).then(function () {
        return autoSyncIfLoggedIn();
      });
    });
  }

  function autoSyncIfLoggedIn() {
    if (!cloudAvailable()) return Promise.resolve();
    return NTSupabase.getStatus().then(function (st) {
      if (!st.loggedIn) return;
      return syncNow();
    }).catch(function () {});
  }

  function mergeIndex(existing, incoming) {
    var seen = {};
    var merged = [];
    existing.concat(incoming).forEach(function (id) {
      if (!seen[id]) { seen[id] = true; merged.push(id); }
    });
    return merged;
  }

  function save(record) {
    return ensureMigrated().then(function () {
      return storeGet(null).then(function (all) {
        var ids = all[STORE_INDEX] || [];
        var existingIds = Object.keys(mapFromAll(all));
        ids = mergeIndex(ids, existingIds);

        var toSet = {};
        toSet[listingKey(record.id)] = record;
        if (ids.indexOf(record.id) === -1) ids = ids.concat(record.id);
        toSet[STORE_INDEX] = ids;
        return storeSet(toSet).then(function () {
          return pushRecord(record, false);
        });
      });
    });
  }

  function remove(id) {
    return ensureMigrated().then(function () {
      return storeGet(null).then(function (all) {
        var existing = all[listingKey(id)] || { id: id, dateUpdated: Date.now() };
        existing.dateUpdated = Date.now();

        var ids = all[STORE_INDEX] || [];
        var existingIds = Object.keys(mapFromAll(all));
        ids = mergeIndex(ids, existingIds).filter(function (x) { return x !== id; });

        var idx = {};
        idx[STORE_INDEX] = ids;
        return storeSet(idx)
          .then(function () {
            return storeRemove([listingKey(id)]);
          })
          .then(function () {
            return pushRecord(existing, true);
          });
      });
    });
  }

  function isListingChange(changes) {
    if (changes[STORE_INDEX]) return true;
    return Object.keys(changes).some(function (k) {
      return k.indexOf(STORE_PREFIX) === 0;
    });
  }

  function syncNow() {
    if (!cloudAvailable()) {
      return Promise.reject(Object.assign(new Error("Cloud modul nije učitan"), { code: "no_cloud" }));
    }
    if (syncInFlight) return syncInFlight;

    syncInFlight = ensureMigrated()
      .then(function () {
        return NTSupabase.getStatus();
      })
      .then(function (st) {
        if (!st.configured) {
          var err = new Error("Supabase nije podešen");
          err.code = "not_configured";
          throw err;
        }
        if (!st.loggedIn) {
          var err2 = new Error("Nisi ulogovan");
          err2.code = "not_logged_in";
          throw err2;
        }
        return Promise.all([readListingsMap(), NTSupabase.fetchListings()]);
      })
      .then(function (pair) {
        var localMap = pair[0];
        var remoteRows = pair[1];
        var merged = NTSyncMerge.mergeMaps(localMap, remoteRows);
        var write = merged.changed ? writeListingsMap(merged.map) : Promise.resolve();
        var push = merged.push.length ? NTSupabase.upsertRows(merged.push) : Promise.resolve();
        return Promise.all([write, push]).then(function () {
          return storeSet((function () {
            var o = {};
            o[SYNC_META_KEY] = Date.now();
            return o;
          })()).then(function () {
            return {
              count: Object.keys(merged.map).length,
              pushed: merged.push.length,
              changed: merged.changed
            };
          });
        });
      })
      .finally(function () {
        syncInFlight = null;
      });

    return syncInFlight;
  }

  function getSyncMeta() {
    return storeGet(SYNC_META_KEY).then(function (res) {
      return { lastSyncAt: res[SYNC_META_KEY] || 0 };
    });
  }

  global.NTStorage = {
    getAll: getAll,
    setAll: setAll,
    save: save,
    remove: remove,
    isListingChange: isListingChange,
    syncNow: syncNow,
    getSyncMeta: getSyncMeta,
    storageArea: "local"
  };
})(typeof self !== "undefined" ? self : window);
