// Pozadinski service worker: kontekstni meni, čuvanje, dedupe, badge, cloud sync.
importScripts("scrape.js", "api-config.js", "sync-merge.js", "api.js", "storage.js");

var NS = self.NS;

function tryCloudSync() {
  if (!NTStorage.syncNow) return;
  NTStorage.syncNow().catch(function () {
    /* nije ulogovan / nije podešeno — OK */
  });
}

function updateBadge() {
  NTStorage.getAll().then(function (map) {
    var n = Object.values(map).filter(function (r) { return r.status !== "rejected"; }).length;
    chrome.action.setBadgeText({ text: n ? String(n) : "" });
    chrome.action.setBadgeBackgroundColor({ color: "#0e7c66" });
  });
}

function isSaveableUrl(url) {
  if (!url) return false;
  try {
    var p = new URL(url).protocol;
    return p === "http:" || p === "https:";
  } catch (e) {
    return false;
  }
}

// Spaja novi snimak sa postojećim zapisom, čuvajući korisnička polja.
async function upsertListing(scraped) {
  var map = await NTStorage.getAll();
  var id = NS.makeId(scraped.url);
  var now = Date.now();
  var existing = map[id];
  var created = !existing;
  var manualPrice = existing && existing.priceManual;
  var manualArea = existing && existing.areaManual;
  // Stranica je kolekcija/projekat (više stanova) -> nema jedne kvadrature/cene.
  var isCollection = scraped.kind === "project";

  var record = {
    id: id,
    url: scraped.url,
    site: scraped.site || (existing && existing.site) || "",
    title: scraped.title || (existing && existing.title) || scraped.url,
    image: scraped.image || (existing && existing.image) || "",
    // Ručno uneta cena ima prednost; za kolekciju se stara (ne-ručna) cena briše.
    price: manualPrice ? existing.price : (isCollection ? null : (scraped.price != null ? scraped.price : (existing ? existing.price : null))),
    priceEstimated: manualPrice ? false : (isCollection ? false : (scraped.price != null ? !!scraped.priceEstimated : (existing ? existing.priceEstimated : false))),
    priceManual: !!manualPrice,
    pricePerM2: scraped.pricePerM2 != null ? scraped.pricePerM2 : (existing ? existing.pricePerM2 : null),
    // Ručno uneta kvadratura ima prednost; za kolekciju se stara (ne-ručna) briše.
    area: manualArea ? existing.area : (isCollection ? null : (scraped.area != null ? scraped.area : (existing ? existing.area : null))),
    areaManual: !!manualArea,
    // Uvek iz novog snimka — briše pogrešan opseg (npr. terasa 5 m² + stan 91 m²).
    areaMin: scraped.areaMin != null ? scraped.areaMin : null,
    areaMax: scraped.areaMax != null ? scraped.areaMax : null,
    rooms: isCollection ? null : (scraped.rooms != null ? scraped.rooms : (existing ? existing.rooms : null)),
    location: scraped.location || (existing && existing.location) || "",
    vat: scraped.vat != null ? scraped.vat : null,
    kind: scraped.kind || "stan",
    rating: existing ? existing.rating : 0,
    priority: existing ? existing.priority : "none",
    status: existing ? existing.status : "to_visit",
    notes: existing ? existing.notes : "",
    dateAdded: existing ? existing.dateAdded : now,
    dateUpdated: now
  };

  map[id] = record;
  await NTStorage.save(record);
  updateBadge();
  return { created: created, record: record };
}

async function offerQuickEdit(record, created) {
  if (!created || !chrome.storage.session) return;
  await chrome.storage.session.set({
    pendingQuickEdit: { id: record.id, created: true, ts: Date.now() }
  });
  if (!chrome.action || !chrome.action.openPopup) return;
  try {
    await chrome.action.openPopup();
  } catch (e) {}
}

// Izvlačenje sa otvorene kartice preko content skripte.
function scrapeTab(tabId) {
  return new Promise(function (resolve) {
    chrome.tabs.sendMessage(tabId, { type: "SCRAPE_CURRENT" }, function (resp) {
      if (chrome.runtime.lastError || !resp || !resp.ok) {
        resolve(null);
      } else {
        resolve(resp.data);
      }
    });
  });
}

// Izvlačenje sa linka (desni klik na link) preko fetch + regex parsiranja.
async function scrapeUrl(url, fallbackTitle) {
  if (!isSaveableUrl(url)) return null;
  try {
    var res = await fetch(url, { credentials: "omit" });
    var html = await res.text();
    var data = NS.parseHtml(html, url);
    if (!data.title && fallbackTitle) data.title = fallbackTitle;
    return data;
  } catch (e) {
    // Nema dozvole za domen ili greška u mreži -> sačuvaj bar URL.
    return {
      url: NS.normalizeUrl(url),
      site: NS.detectSite(url),
      title: fallbackTitle || url,
      image: "",
      price: null,
      priceEstimated: false,
      pricePerM2: null,
      area: null,
      areaMin: null,
      areaMax: null,
      rooms: null,
      location: "",
      vat: null,
      kind: "stan"
    };
  }
}

// Meni se mora (re)registrovati i van onInstalled — MV3 SW može da padne
// pre create-a, pa "Sačuvaj ovu nekretninu" nestane dok se ekstenzija ne reload-uje.
var CONTEXT_MENUS = [
  {
    id: "save-page",
    title: "Sačuvaj ovu nekretninu",
    contexts: ["page", "selection", "image"]
  },
  {
    id: "save-link",
    title: "Sačuvaj link nekretnine",
    contexts: ["link"]
  },
  {
    id: "open-list",
    title: "Otvori listu nekretnina",
    contexts: ["action"]
  }
];

function ensureContextMenus() {
  chrome.contextMenus.removeAll(function () {
    CONTEXT_MENUS.forEach(function (item) {
      chrome.contextMenus.create(item, function () {
        void chrome.runtime.lastError;
      });
    });
  });
}

ensureContextMenus();

chrome.runtime.onInstalled.addListener(function () {
  ensureContextMenus();
  updateBadge();
  tryCloudSync();
});

chrome.runtime.onStartup.addListener(function () {
  ensureContextMenus();
  updateBadge();
  tryCloudSync();
});

chrome.contextMenus.onClicked.addListener(async function (info, tab) {
  if (info.menuItemId === "open-list") {
    chrome.tabs.create({ url: chrome.runtime.getURL("list.html") });
    return;
  }
  if (info.menuItemId === "save-link" && info.linkUrl) {
    if (!isSaveableUrl(info.linkUrl)) return;
    var data = await scrapeUrl(info.linkUrl, info.selectionText || "");
    if (data) {
      var linkResult = await upsertListing(data);
      await offerQuickEdit(linkResult.record, linkResult.created);
    }
    return;
  }
  if (info.menuItemId === "save-page" && tab && tab.id) {
    if (!isSaveableUrl(tab.url)) return;
    var fromTab = await scrapeTab(tab.id);
    if (!fromTab && tab.url) fromTab = await scrapeUrl(tab.url, tab.title || "");
    if (fromTab) {
      var pageResult = await upsertListing(fromTab);
      await offerQuickEdit(pageResult.record, pageResult.created);
    }
  }
});

// Poruke iz popup-a / liste.
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.type === "SAVE_CURRENT_TAB") {
    (async function () {
      try {
        var tab = msg.tab;
        if (!tab || !isSaveableUrl(tab.url)) {
          sendResponse({ ok: false, reason: "unsupported_url" });
          return;
        }
        var data = tab.id ? await scrapeTab(tab.id) : null;
        if (!data && tab && tab.url) data = await scrapeUrl(tab.url, tab.title || "");
        if (!data) { sendResponse({ ok: false, reason: "scrape_failed" }); return; }
        var r = await upsertListing(data);
        sendResponse({ ok: true, created: r.created, record: r.record });
      } catch (e) {
        sendResponse({ ok: false, reason: "save_failed", error: String(e) });
      }
    })();
    return true;
  }
  if (msg && msg.type === "SAVE_URL") {
    (async function () {
      if (!isSaveableUrl(msg.url)) {
        sendResponse({ ok: false, reason: "unsupported_url" });
        return;
      }
      var data = await scrapeUrl(msg.url, msg.title || "");
      if (!data) {
        sendResponse({ ok: false, reason: "unsupported_url" });
        return;
      }
      var r = await upsertListing(data);
      sendResponse({ ok: true, created: r.created, record: r.record });
    })();
    return true;
  }
  if (msg && msg.type === "REFRESH_BADGE") {
    updateBadge();
  }
  if (msg && msg.type === "SYNC_NOW") {
    (async function () {
      try {
        var r = await NTStorage.syncNow();
        updateBadge();
        sendResponse({ ok: true, result: r });
      } catch (e) {
        sendResponse({
          ok: false,
          code: e && e.code,
          error: e && e.message ? e.message : String(e)
        });
      }
    })();
    return true;
  }
  if (msg && msg.type === "OPEN_OPTIONS") {
    if (chrome.runtime.openOptionsPage) chrome.runtime.openOptionsPage();
    else chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
  }
});
