(function () {
  "use strict";

  var panelLoggedIn = document.getElementById("panel-logged-in");
  var panelGuest = document.getElementById("panel-guest");
  var userDisplay = document.getElementById("user-display");
  var userAvatar = document.getElementById("user-avatar");
  var syncStatus = document.getElementById("sync-status");
  var msgEl = document.getElementById("msg");

  var loginUserEl = document.getElementById("login-username");
  var loginPassEl = document.getElementById("login-password");
  var registerUserEl = document.getElementById("register-username");
  var registerPassEl = document.getElementById("register-password");

  function showMsg(text, ok) {
    msgEl.hidden = !text;
    msgEl.textContent = text || "";
    msgEl.className = "msg " + (ok ? "ok" : "err");
  }

  function fmtTime(ts) {
    if (!ts) return "nikad";
    return new Date(ts).toLocaleString("sr-RS", {
      day: "numeric",
      month: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  }

  function avatarLetter(name) {
    var s = String(name || "?").trim();
    return s ? s.charAt(0).toUpperCase() : "?";
  }

  function setTab(tab) {
    document.querySelectorAll(".auth-tab").forEach(function (btn) {
      var on = btn.getAttribute("data-tab") === tab;
      btn.classList.toggle("active", on);
      btn.setAttribute("aria-selected", on ? "true" : "false");
    });
    document.getElementById("tab-login").classList.toggle("hidden", tab !== "login");
    document.getElementById("tab-register").classList.toggle("hidden", tab !== "register");
    showMsg("");
  }

  function setAuthMode(loggedIn) {
    panelLoggedIn.classList.toggle("hidden", !loggedIn);
    panelGuest.classList.toggle("hidden", loggedIn);
  }

  function refresh() {
    return Promise.all([NTApi.getStatus(), NTStorage.getSyncMeta()]).then(function (pair) {
      var st = pair[0];
      var meta = pair[1];

      if (st.loggedIn) {
        setAuthMode(true);
        var name = st.username || "korisnik";
        userDisplay.textContent = name;
        userAvatar.textContent = avatarLetter(name);
      } else {
        setAuthMode(false);
      }

      syncStatus.textContent = "Poslednji sync: " + fmtTime(meta.lastSyncAt);
    });
  }

  document.querySelectorAll(".auth-tab").forEach(function (btn) {
    btn.addEventListener("click", function () {
      setTab(btn.getAttribute("data-tab"));
    });
  });

  document.getElementById("sign-in").addEventListener("click", function () {
    showMsg("");
    NTApi.signIn(loginUserEl.value, loginPassEl.value)
      .then(function () {
        loginPassEl.value = "";
        return NTStorage.syncNow();
      })
      .then(function (r) {
        showMsg("Ulogovan. Sinhronizovano " + r.count + " oglasa.", true);
        return refresh();
      })
      .catch(function (e) {
        showMsg(e.message || String(e), false);
        refresh();
      });
  });

  document.getElementById("sign-up").addEventListener("click", function () {
    showMsg("");
    NTApi.signUp(registerUserEl.value, registerPassEl.value)
      .then(function (r) {
        registerPassEl.value = "";
        if (r.needsConfirm) {
          showMsg("Nalog kreiran — u Supabase isključi email confirm, pa se uloguj.", true);
          setTab("login");
          if (registerUserEl.value) loginUserEl.value = registerUserEl.value;
          return refresh();
        }
        return NTStorage.syncNow().then(function (sync) {
          showMsg("Nalog kreiran. Sinhronizovano " + sync.count + " oglasa.", true);
          return refresh();
        });
      })
      .catch(function (e) {
        showMsg(e.message || String(e), false);
        refresh();
      });
  });

  document.getElementById("sign-out").addEventListener("click", function () {
    showMsg("");
    NTApi.signOut()
      .then(function () {
        showMsg("Odjavljen. Lokalni oglasi ostaju na ovom uređaju.", true);
        loginPassEl.value = "";
        registerPassEl.value = "";
        return refresh();
      })
      .catch(function (e) {
        showMsg(e.message || String(e), false);
      });
  });

  loginPassEl.addEventListener("keydown", function (e) {
    if (e.key === "Enter") document.getElementById("sign-in").click();
  });
  registerPassEl.addEventListener("keydown", function (e) {
    if (e.key === "Enter") document.getElementById("sign-up").click();
  });

  setTab("login");
  refresh();
})();
