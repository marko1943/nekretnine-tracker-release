(function () {
  "use strict";

  var apiUrlEl = document.getElementById("api-url");
  var userEl = document.getElementById("username");
  var passEl = document.getElementById("password");
  var authStatus = document.getElementById("auth-status");
  var syncStatus = document.getElementById("sync-status");
  var msgEl = document.getElementById("msg");

  function showMsg(text, ok) {
    msgEl.hidden = !text;
    msgEl.textContent = text || "";
    msgEl.className = "msg " + (ok ? "ok" : "err");
  }

  function fmtTime(ts) {
    if (!ts) return "nikad";
    return new Date(ts).toLocaleString("sr-RS");
  }

  function refresh() {
    return Promise.all([NTApi.getStatus(), NTStorage.getSyncMeta(), NTApi.getConfig()]).then(function (pair) {
      var st = pair[0];
      var meta = pair[1];
      var cfg = pair[2];
      if (cfg.apiUrl) apiUrlEl.value = cfg.apiUrl;
      if (st.loggedIn) {
        authStatus.textContent = "Ulogovan: " + (st.username || "da");
        if (st.username && !userEl.value) userEl.value = st.username;
      } else if (st.configured) {
        authStatus.textContent = "Spremno — unesi username i lozinku (ili Registruj).";
      } else {
        authStatus.textContent = "Nema API URL — popuni src/api-config.js (posle deploy Workera).";
      }
      syncStatus.textContent = "Poslednji sync: " + fmtTime(meta.lastSyncAt);
    });
  }

  document.getElementById("save-cfg").addEventListener("click", function () {
    showMsg("");
    NTApi.saveConfig(apiUrlEl.value)
      .then(function () {
        showMsg("API URL sačuvan.", true);
        return refresh();
      })
      .catch(function (e) {
        showMsg(e.message || String(e), false);
      });
  });

  document.getElementById("sign-in").addEventListener("click", function () {
    showMsg("");
    NTApi.signIn(userEl.value, passEl.value)
      .then(function () {
        passEl.value = "";
        return NTStorage.syncNow();
      })
      .then(function (r) {
        showMsg("Ulogovan i sinhronizovano (" + r.count + " oglasa).", true);
        return refresh();
      })
      .catch(function (e) {
        showMsg(e.message || String(e), false);
        refresh();
      });
  });

  document.getElementById("sign-up").addEventListener("click", function () {
    showMsg("");
    NTApi.signUp(userEl.value, passEl.value)
      .then(function (r) {
        passEl.value = "";
        if (r.needsConfirm) {
          showMsg("Nalog kreiran — u Supabase isključi email confirm, pa se uloguj.", true);
          return refresh();
        }
        return NTStorage.syncNow().then(function (sync) {
          showMsg("Nalog kreiran, sync OK (" + sync.count + ").", true);
          return refresh();
        });
      })
      .catch(function (e) {
        showMsg(e.message || String(e), false);
        refresh();
      });
  });

  document.getElementById("sign-out").addEventListener("click", function () {
    showMsg("");
    NTApi.signOut()
      .then(function () {
        showMsg("Odjavljen. Lokalni oglasi ostaju na ovom računaru.", true);
        return refresh();
      })
      .catch(function (e) {
        showMsg(e.message || String(e), false);
      });
  });

  document.getElementById("sync-now").addEventListener("click", function () {
    showMsg("Sync…", true);
    NTStorage.syncNow()
      .then(function (r) {
        showMsg("Gotovo: " + r.count + " oglasa (push " + r.pushed + ").", true);
        chrome.runtime.sendMessage({ type: "REFRESH_BADGE" });
        return refresh();
      })
      .catch(function (e) {
        showMsg(e.message || String(e), false);
        refresh();
      });
  });

  passEl.addEventListener("keydown", function (e) {
    if (e.key === "Enter") document.getElementById("sign-in").click();
  });

  refresh();
})();
