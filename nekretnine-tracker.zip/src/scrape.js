// Zajednička logika za izvlačenje podataka o nekretnini.
// Bezbedno se učitava i u content skripti (ima document) i u service workeru
// (importScripts) - na vrhu nema pristupa DOM-u.
(function (root) {
  "use strict";

  var SITES = {
    "4zida.rs": "4zida",
    "halooglasi.com": "Halo oglasi",
    "nekretnine.rs": "Nekretnine.rs",
    "cityexpert.rs": "CityExpert",
    "stan2.rs": "Stan2",
    "distriktnekretnine.rs": "Distrikt Nekretnine"
  };

  function detectSite(url) {
    try {
      var host = new URL(url).hostname.replace(/^www\./, "");
      for (var key in SITES) {
        if (host === key || host.endsWith("." + key)) return SITES[key];
      }
      return host;
    } catch (e) {
      return "";
    }
  }

  function normalizeUrl(url) {
    try {
      var u = new URL(url);
      u.hash = "";
      var drop = [];
      u.searchParams.forEach(function (v, k) {
        if (/^utm_/i.test(k) || k === "fbclid" || k === "gclid") drop.push(k);
      });
      drop.forEach(function (k) { u.searchParams.delete(k); });
      return u.toString();
    } catch (e) {
      return url;
    }
  }

  // Stabilan kratak id iz URL-a.
  function makeId(url) {
    var s = normalizeUrl(url);
    var h = 5381;
    for (var i = 0; i < s.length; i++) {
      h = ((h << 5) + h + s.charCodeAt(i)) | 0;
    }
    return "n" + (h >>> 0).toString(36);
  }

  function stripPerM2(text) {
    return String(text).replace(/[\d.,]+\s*(€|eur|din|rsd)?\s*\/\s*m\s*[²2]/gi, " ");
  }

  // Čist broj iz pouzdanog polja (npr. og:product:price:amount = "185000").
  function parseAmount(s) {
    if (s == null) return null;
    var v = parseInt(String(s).replace(/[^\d]/g, ""), 10);
    return isNaN(v) || v < 1000 ? null : v;
  }

  // Cena iz slobodnog teksta: MORA da ima valutu (da ne pokupi ID/godinu/telefon).
  // Hvata "120.000 €", "120000 EUR", "85 000 €". Ignoriše "1.250 €/m²".
  function parsePrice(text) {
    if (!text) return null;
    var m = stripPerM2(text).match(/(\d{1,3}(?:[.\s]\d{3})+|\d{4,})(?:[,.]\d{1,2})?\s*(?:€|eur|din|rsd)/i);
    if (!m) return null;
    var val = parseInt(m[1].replace(/[.\s]/g, ""), 10);
    return isNaN(val) || val < 1000 ? null : val;
  }

  // Cena iz teksta vezana za oznaku "Cena" (preciznije za detaljne strane).
  // Ne hvata parking/garažu/ID jer nisu uz reč "cena"; ignoriše €/m².
  function parsePriceLabeled(text) {
    if (!text) return null;
    var m = stripPerM2(text).match(/(?:cena|cijena)\b[^0-9]{0,15}(\d{1,3}(?:[.\s]\d{3})+|\d{4,})(?:[,.]\d{1,2})?\s*(?:€|eur|din|rsd)?/i);
    if (!m) return null;
    var val = parseInt(m[1].replace(/[.\s]/g, ""), 10);
    return isNaN(val) || val < 1000 ? null : val;
  }

  // Cena po kvadratu: vraća broj (EUR/m²) ili null. Hvata "1.250 €/m²".
  function parsePricePerM2(text) {
    if (!text) return null;
    var m = String(text).match(/(\d{1,3}(?:[.\s]\d{3})+|\d{3,6})(?:[,.]\d{1,2})?\s*(?:€|eur|rsd|din)?\s*\/\s*m\s*(?:²|2)/i);
    if (!m) return null;
    var val = parseInt(m[1].replace(/[.\s]/g, ""), 10);
    if (isNaN(val) || val < 100 || val > 100000) return null;
    return val;
  }

  function validArea(val) {
    return !(isNaN(val) || val <= 0 || val > 100000) ? val : null;
  }

  // Opseg kvadrature (npr. "44.62-60m²" na 4zida novogradnji).
  function parseAreaRange(text) {
    if (!text) return null;
    var m = String(text).match(/(\d{1,4}(?:[.,]\d{1,2})?)\s*[-–]\s*(\d{1,4}(?:[.,]\d{1,2})?)\s*m\s*(?:²|2)(?![0-9])/i);
    if (!m) return null;
    var min = validArea(parseFloat(m[1].replace(",", ".")));
    var max = validArea(parseFloat(m[2].replace(",", ".")));
    if (min == null || max == null || min > max) return null;
    return { min: min, max: max };
  }

  function isProjectUrl(url) {
    try {
      var p = new URL(url).pathname.toLowerCase();
      return p.indexOf("/novogradnja/") !== -1 || p.indexOf("/a/novogradnja/") !== -1;
    } catch (e) {
      return false;
    }
  }

  function listingKind(data, url) {
    if (data.areaMin != null && data.areaMax != null) return "project";
    if (isProjectUrl(url) && !data.area) return "project";
    return "stan";
  }

  // Kvadratura: vraća broj m² ili null. Hvata "65 m²", "65,5 m2".
  function parseArea(text) {
    if (!text) return null;
    var m = String(text).match(/(\d{1,4}(?:[.,]\d{1,2})?)\s*m\s*(?:²|2)(?![0-9])/i);
    if (!m) return null;
    return validArea(parseFloat(m[1].replace(",", ".")));
  }

  var AREA_LABEL_RE = /(?:kvadratura|stambena\s+povr[sš]ina|povr[sš]ina|korisna\s+povr[sš]ina)\s*:?\s*(\d{1,4}(?:[.,]\d{1,2})?)\s*m\s*(?:²|2)(?![0-9])/gi;

  // Pouzdanije: kvadratura iz označenog polja ("Kvadratura 90 m2", "Površina: 65 m²").
  function parseAreaLabeled(text) {
    if (!text) return null;
    AREA_LABEL_RE.lastIndex = 0;
    var m = AREA_LABEL_RE.exec(String(text));
    if (!m) return null;
    return validArea(parseFloat(m[1].replace(",", ".")));
  }

  // Statistika označenih kvadratura: broj RAZLIČITIH + min/max.
  // Više različitih kvadratura = kolekcija (projekat / rezultati pretrage), ne jedan oglas.
  function areaStats(text) {
    var seen = {};
    if (text) {
      AREA_LABEL_RE.lastIndex = 0;
      var m;
      while ((m = AREA_LABEL_RE.exec(String(text)))) {
        var v = validArea(parseFloat(m[1].replace(",", ".")));
        if (v != null) seen[v] = true;
      }
    }
    var vals = Object.keys(seen).map(Number);
    return {
      distinct: vals.length,
      min: vals.length ? Math.min.apply(null, vals) : null,
      max: vals.length ? Math.max.apply(null, vals) : null
    };
  }

  // PDV status: "with" | "without" | null. Pažljivo da ne pomeša parking/garažu.
  function parseVat(text) {
    if (!text) return null;
    var t = stripDiacriticsLower(String(text));
    // 1) Kontekst odmah posle GLAVNE cene (ukupne ili po m²) - najjači signal.
    var m = t.match(/(?:cena|cijena)\b[^0-9]{0,15}\d[\d.,\s]*(?:eur|din|rsd|€)?\s*(?:\/\s*m\s*(?:2|²))?([^.|·\n]{0,30})/i);
    if (m) {
      var ctx = m[1];
      if (/\+\s*pdv|bez\s*pdv|pdv\s*nije/.test(ctx)) return "without";
      if (/sa\s*pdv|pdv\s*ukljuc|pdv\s*uracun|uracunat\w*\s*pdv/.test(ctx)) return "with";
    }
    // 2) Jasne fraze bilo gde (vezane za cenu nekretnine, ne za parking "sa PDV-om").
    if (/cena\s*bez\s*pdv|bez\s*ukljucenog\s*pdv|cena\s*ne\s*sadrzi\s*pdv/.test(t)) return "without";
    if (/uracunat\w*\s+(?:je\s+)?pdv|pdv\s+(?:je\s+)?uracunat|u\s*cenu\s*(?:je\s*)?uracunat\w*\s*pdv|povracaj\w*\s*pdv|pdv\s*uklju/.test(t)) return "with";
    return null;
  }

  function stripDiacriticsLower(s) {
    return s.toLowerCase()
      .replace(/č|ć/g, "c").replace(/š/g, "s").replace(/ž/g, "z").replace(/đ/g, "dj");
  }

  // Broj soba (best-effort).
  function parseRooms(text) {
    if (!text) return null;
    var t = String(text).toLowerCase();
    var map = { garsonjer: 0.5, jednosoban: 1, jednoiposoban: 1.5, dvosoban: 2, dvoiposoban: 2.5, trosoban: 3, troiposoban: 3.5, cetvorosoban: 4, "četvorosoban": 4 };
    for (var k in map) { if (t.indexOf(k) !== -1) return map[k]; }
    var m = t.match(/(\d(?:[.,]\d)?)\s*(?:soba|sobe|soban|sobni)/);
    if (m) return parseFloat(m[1].replace(",", "."));
    return null;
  }

  // Pouzdanije: broj soba iz označenog polja. Podržava oba reda reči:
  // "Sobe 3.5" / "Broj soba: 2" i "3 sobe". Štiti od "1/3" (indikator slajda).
  function parseRoomsLabeled(text) {
    if (!text) return null;
    var s = String(text);
    var m = s.match(/(?:broj\s+soba|\bsobe?\b)\s*:?\s*(\d(?:[.,]\d)?)(?!\s*[\/\d])/i);
    if (!m) m = s.match(/(\d(?:[.,]\d)?)\s*(?:sobe|soba|soban|sobni)\b/i);
    if (!m) return null;
    var v = parseFloat(m[1].replace(",", "."));
    return isNaN(v) || v < 0 || v > 20 ? null : v;
  }

  // ---- JSON-LD: spljošti sve čvorove (uključujući @graph) i agregiraj polja ----
  function flattenLd(blocks) {
    var out = [];
    for (var i = 0; i < blocks.length; i++) {
      var b = blocks[i];
      if (!b) continue;
      var arr = Array.isArray(b) ? b : (b["@graph"] ? b["@graph"] : [b]);
      for (var j = 0; j < arr.length; j++) {
        if (arr[j] && typeof arr[j] === "object") out.push(arr[j]);
      }
    }
    return out;
  }

  function ldTypeStr(node) {
    return JSON.stringify(node["@type"] || "");
  }

  function ldPrice(nodes) {
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      var offers = n.offers;
      if (Array.isArray(offers)) offers = offers[0];
      var p = offers && (offers.price || offers.lowPrice);
      if (p == null && /Offer/i.test(ldTypeStr(n))) p = n.price;
      if (p != null) {
        var v = parseInt(String(p).replace(/[^\d]/g, ""), 10);
        if (!isNaN(v) && v >= 1000) return v;
      }
    }
    return null;
  }

  function ldArea(nodes) {
    for (var i = 0; i < nodes.length; i++) {
      var fs = nodes[i].floorSize;
      if (fs) {
        var v = typeof fs === "object" ? fs.value : fs;
        var n = parseFloat(v);
        if (!isNaN(n) && n > 0 && n < 100000) return n;
      }
    }
    return null;
  }

  function ldRooms(nodes) {
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      var r = node.numberOfRooms != null ? node.numberOfRooms : node.numberOfBedrooms;
      if (r != null) {
        if (typeof r === "object") r = r.value;
        var v = parseFloat(r);
        if (!isNaN(v) && v >= 0 && v <= 20) return v;
      }
    }
    return null;
  }

  function nodeImage(node) {
    if (!node.image) return null;
    var img = node.image;
    if (Array.isArray(img)) img = img[0];
    if (img && typeof img === "object") img = img.url || img.contentUrl;
    return typeof img === "string" ? img : null;
  }

  function ldImage(nodes) {
    // Prvo slika iz čvora nekretnine, pa tek onda bilo koji (preskoči logo organizacije).
    var prefer = /Apartment|RealEstate|Residence|House|Product|Place/i;
    var i, img;
    for (i = 0; i < nodes.length; i++) {
      if (prefer.test(ldTypeStr(nodes[i])) && (img = nodeImage(nodes[i]))) return img;
    }
    for (i = 0; i < nodes.length; i++) {
      if (/Organization|WebSite|WebPage|Breadcrumb/i.test(ldTypeStr(nodes[i]))) continue;
      if ((img = nodeImage(nodes[i]))) return img;
    }
    return null;
  }

  // ---- DOM režim (content skripta) ----
  function metaContent(doc, selectors) {
    for (var i = 0; i < selectors.length; i++) {
      var el = doc.querySelector(selectors[i]);
      if (el && el.content) return el.content;
    }
    return null;
  }

  function collectJsonLd(doc) {
    var out = [];
    var scripts = doc.querySelectorAll('script[type="application/ld+json"]');
    for (var i = 0; i < scripts.length; i++) {
      try { out.push(JSON.parse(scripts[i].textContent)); } catch (e) {}
    }
    return out;
  }

  // Otvorena stranica: koristimo IZRENDEROVANI HTML i isti put kao za fetch (parseHtml),
  // da rezultat bude identičan i da SPA/lazy sadržaj (npr. lista stanova) bude uključen.
  function scrapeDocument(doc, url) {
    doc = doc || (typeof document !== "undefined" ? document : null);
    url = url || (doc && doc.location ? doc.location.href : "");
    if (!doc) return null;

    var html = (doc.documentElement && doc.documentElement.outerHTML) || "";
    var result = parseHtml(html, url);

    // DOM dopuna: ako naslov nedostaje, probaj h1; slika iz og kao rezerva.
    if (!result.title) {
      var h1 = doc.querySelector && doc.querySelector("h1");
      if (h1) result.title = h1.textContent.replace(/\s+/g, " ").trim().slice(0, 200);
    }
    return result;
  }

  // ---- Regex režim (service worker, parsiranje fetch HTML-a) ----
  function attr(tag, name) {
    var re = new RegExp(name + '\\s*=\\s*"([^"]*)"', "i");
    var m = tag.match(re);
    return m ? m[1] : null;
  }

  function metaFromHtml(html, prop) {
    var re = new RegExp('<meta[^>]+(?:property|name)\\s*=\\s*"' + prop + '"[^>]*>', "i");
    var m = html.match(re);
    if (!m) return null;
    return attr(m[0], "content");
  }

  function collectJsonLdFromHtml(html) {
    var out = [];
    var re = /<script[^>]+type\s*=\s*"application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi;
    var m;
    while ((m = re.exec(html))) {
      try { out.push(JSON.parse(m[1].trim())); } catch (e) {}
    }
    return out;
  }

  function decodeEntities(s) {
    if (!s) return s;
    return s
      .replace(/&nbsp;/gi, " ")
      .replace(/&#x([0-9a-f]+);/gi, function (_, h) { return String.fromCharCode(parseInt(h, 16)); })
      .replace(/&#(\d+);/g, function (_, n) { return String.fromCharCode(parseInt(n, 10)); })
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&amp;/g, "&");
  }

  function parseHtml(html, url) {
    if (!html) return buildResult(url, "", "", null, null, null, "");
    var nodes = flattenLd(collectJsonLdFromHtml(html));

    var title =
      decodeEntities(metaFromHtml(html, "og:title")) ||
      decodeEntities((html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1]) ||
      "";
    title = (title || "").trim();

    var image = ldImage(nodes) || decodeEntities(metaFromHtml(html, "og:image")) || "";

    // grub tekst bez tagova za regex cene/površine
    var text = html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ");
    text = decodeEntities(text);

    var price = ldPrice(nodes) || parseAmount(metaFromHtml(html, "product:price:amount")) || parsePrice(title) || parsePriceLabeled(text);
    var range = parseAreaRange(text);
    var projectPage = isProjectUrl(url);
    var stats = areaStats(text);
    if (range && projectPage && stats.distinct < 2) {
      stats = { distinct: 2, min: range.min, max: range.max };
    }
    var multiUnit = stats.distinct >= 3 || (projectPage && range != null) || projectPage;
    if (multiUnit) {
      // JSON-LD Offer često nosi jedan primer stana — ne koristiti za projekat /novogradnja.
      price = parsePrice(title) || parsePriceLabeled(text) || null;
    }
    var area = multiUnit ? null : (ldArea(nodes) || parseAreaLabeled(text) || parseArea(title) || parseArea(text));
    // vidi napomenu u scrapeDocument: sobe iz JSON-LD/naslova/označenog polja
    var rooms = multiUnit ? null : (ldRooms(nodes) || parseRooms(title) || parseRoomsLabeled(text));
    var pricePerM2 = parsePricePerM2(title) || parsePricePerM2(text);

    var result = buildResult(url, title, image, price, area, rooms, "", pricePerM2);
    result.vat = parseVat(text);
    if (multiUnit) {
      if (range) {
        result.areaMin = range.min;
        result.areaMax = range.max;
      } else if (stats.distinct >= 2 && stats.min != null && stats.max != null) {
        result.areaMin = stats.min;
        result.areaMax = stats.max;
      }
    }
    result.kind = listingKind(result, url);
    return result;
  }

  function buildResult(url, title, image, price, area, rooms, location, pricePerM2) {
    price = price || null;
    area = area || null;
    pricePerM2 = pricePerM2 || null;
    var priceEstimated = false;

    // Heuristika za "na kvadrat" sajtove: ako je "cena" zapravo cena po m²
    // (nema eksplicitnog €/m², a implicirana ukupna €/m² je nemoguće niska za prodaju),
    // tretiraj je kao €/m² i proceni ukupnu cenu.
    if (price && area && !pricePerM2 && price >= 200 && price <= 20000 && price / area < 150) {
      pricePerM2 = price;
      price = Math.round(price * area);
      priceEstimated = true;
    }

    // Nema ukupne cene, ali znamo €/m² i kvadraturu -> proceni ukupnu cenu.
    if (!price && pricePerM2 && area) {
      price = Math.round(pricePerM2 * area);
      priceEstimated = true;
    }
    // Nema €/m², ali znamo ukupnu cenu i kvadraturu -> izračunaj €/m².
    if (!pricePerM2 && price && area) {
      pricePerM2 = Math.round(price / area);
    }

    return {
      url: normalizeUrl(url),
      site: detectSite(url),
      title: (title || "").replace(/\s+/g, " ").trim().slice(0, 200),
      image: image || "",
      price: price,
      priceEstimated: priceEstimated,
      pricePerM2: pricePerM2,
      area: area,
      areaMin: null,
      areaMax: null,
      rooms: rooms != null ? rooms : null,
      location: (location || "").trim(),
      vat: null,
      kind: "stan"
    };
  }

  root.NS = {
    detectSite: detectSite,
    normalizeUrl: normalizeUrl,
    makeId: makeId,
    parsePrice: parsePrice,
    parsePriceLabeled: parsePriceLabeled,
    parseAmount: parseAmount,
    parsePricePerM2: parsePricePerM2,
    parseArea: parseArea,
    parseAreaRange: parseAreaRange,
    isProjectUrl: isProjectUrl,
    listingKind: listingKind,
    parseVat: parseVat,
    areaStats: areaStats,
    parseRooms: parseRooms,
    scrapeDocument: scrapeDocument,
    parseHtml: parseHtml
  };
})(typeof self !== "undefined" ? self : this);
