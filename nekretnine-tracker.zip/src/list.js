(function () {
  "use strict";

  var grid = document.getElementById("grid");
  var emptyEl = document.getElementById("empty");
  var tpl = document.getElementById("card-tpl");
  var resultCount = document.getElementById("result-count");

  var filters = {
    search: document.getElementById("search"),
    site: document.getElementById("f-site"),
    status: document.getElementById("f-status"),
    priority: document.getElementById("f-priority"),
    rating: document.getElementById("f-rating"),
    groupKeywords: document.getElementById("group-keywords"),
    sort: document.getElementById("f-sort")
  };

  var PRIORITY_RANK = { high: 3, medium: 2, low: 1, none: 0 };
  var STATUS_LABEL = {
    to_visit: "Za obilazak",
    contacted: "Kontaktiran",
    visited: "Obišao",
    rejected: "Odbačeno"
  };

  var cache = {};
  var localWriteDepth = 0;

  function getAll() {
    return NTStorage.getAll();
  }

  function saveRecord(record) {
    cache[record.id] = record;
    localWriteDepth++;
    NTStorage.save(record).then(function () {
      chrome.runtime.sendMessage({ type: "REFRESH_BADGE" });
      localWriteDepth--;
    });
  }

  function deleteRecord(id) {
    delete cache[id];
    localWriteDepth++;
    NTStorage.remove(id).then(function () {
      chrome.runtime.sendMessage({ type: "REFRESH_BADGE" });
      localWriteDepth--;
      render();
    });
  }

  function listingKind(record) {
    if (record.kind === "project" || record.kind === "stan") return record.kind;
    // Zastareli zapis: opseg + jedna kvadratura = i dalje stan (terasa u areaMin).
    if (record.area && record.areaMin != null && record.areaMax != null && record.area >= record.areaMin) return "stan";
    if (record.areaMin != null && record.areaMax != null) return "project";
    try {
      var p = new URL(record.url).pathname.toLowerCase();
      if (p.indexOf("/novogradnja/") !== -1 || p.indexOf("/a/novogradnja/") !== -1) return "project";
    } catch (e) {}
    return "stan";
  }

  function isPriceByArea(record) {
    return record.areaMin != null && record.areaMax != null;
  }

  function missingPriceLabel(record) {
    if (listingKind(record) === "project") return "Po kvadraturi";
    return isPriceByArea(record) ? "Po kvadraturi" : "Cena nepoznata";
  }

  function missingPriceTitle(record) {
    if (listingKind(record) === "project" || isPriceByArea(record)) {
      return "Više stanova u ponudi — cena zavisi od kvadrature. Klik za ručni unos.";
    }
    return "Klik da uneseš cenu";
  }

  function fmtPrice(p, record) {
    return p ? p.toLocaleString("sr-RS") + " €" : missingPriceLabel(record || {});
  }

  function fmtDate(ts) {
    if (!ts) return "";
    var d = new Date(ts);
    return d.toLocaleDateString("sr-RS", { day: "2-digit", month: "2-digit", year: "numeric" });
  }

  function parseKeywords(query) {
    return query.toLowerCase().split(/\s+/).filter(Boolean);
  }

  function parseGroupKeywords(query) {
    return query.split(/[,;]+/).map(function (s) { return s.trim(); }).filter(Boolean);
  }

  function recordHaystack(record) {
    return (record.title + " " + record.location + " " + record.notes + " " + record.site).toLowerCase();
  }

  function matchesKeyword(record, keyword) {
    return recordHaystack(record).indexOf(keyword.toLowerCase()) !== -1;
  }

  function matchesKeywords(record, keywords) {
    if (!keywords.length) return true;
    for (var i = 0; i < keywords.length; i++) {
      if (!matchesKeyword(record, keywords[i])) return false;
    }
    return true;
  }

  function buildKeywordGroups(records, keywords) {
    var groups = keywords.map(function (kw) {
      return {
        key: kw.toLowerCase(),
        label: kw,
        records: records.filter(function (r) { return matchesKeyword(r, kw); })
      };
    }).filter(function (g) { return g.records.length > 0; });

    var matched = {};
    groups.forEach(function (g) {
      g.records.forEach(function (r) { matched[r.id] = true; });
    });
    var rest = records.filter(function (r) { return !matched[r.id]; });
    if (rest.length) {
      groups.push({ key: "__other__", label: "Ostalo", records: rest });
    }
    return groups;
  }

  function editPrice(record) {
    var input = prompt("Unesi cenu u EUR (ostavi prazno za nepoznato):", record.price || "");
    if (input === null) return;
    input = input.trim();
    if (input === "") {
      record.price = null;
      record.priceEstimated = false;
      record.priceManual = true;
    } else {
      var v = parseInt(input.replace(/[^\d]/g, ""), 10);
      if (isNaN(v) || v <= 0) { alert("Neispravan broj."); return; }
      record.price = v;
      record.priceEstimated = false;
      record.priceManual = true;
      if (record.area) record.pricePerM2 = Math.round(v / record.area);
    }
    saveRecord(record);
    render();
  }

  function editArea(record) {
    var input = prompt("Unesi kvadraturu u m² (ostavi prazno za nepoznato):", record.area || "");
    if (input === null) return;
    input = input.trim().replace(",", ".");
    if (input === "") {
      record.area = null;
    } else {
      var v = parseFloat(input);
      if (isNaN(v) || v <= 0) { alert("Neispravan broj."); return; }
      record.area = v;
    }
    record.areaManual = true;
    // Auto-preračun: ako imamo €/m² i kvadraturu (a cena nije ručno uneta) -> proceni cenu.
    if (record.area && record.pricePerM2 && !record.priceManual) {
      record.price = Math.round(record.pricePerM2 * record.area);
      record.priceEstimated = true;
    } else if (record.area && record.price && !record.pricePerM2) {
      record.pricePerM2 = Math.round(record.price / record.area);
    }
    saveRecord(record);
    render();
  }

  function populateSiteFilter(records) {
    var sites = {};
    records.forEach(function (r) { if (r.site) sites[r.site] = true; });
    var current = filters.site.value;
    filters.site.innerHTML = '<option value="">Svi sajtovi</option>';
    Object.keys(sites).sort().forEach(function (s) {
      var opt = document.createElement("option");
      opt.value = s;
      opt.textContent = s;
      filters.site.appendChild(opt);
    });
    filters.site.value = current;
  }

  function applyFilters(records) {
    var keywords = parseKeywords(filters.search.value);
    var site = filters.site.value;
    var status = filters.status.value;
    var prio = filters.priority.value;
    var minRating = parseInt(filters.rating.value, 10) || 0;

    var out = records.filter(function (r) {
      if (site && r.site !== site) return false;
      if (status && r.status !== status) return false;
      if (prio && r.priority !== prio) return false;
      if (minRating && (r.rating || 0) < minRating) return false;
      if (!matchesKeywords(r, keywords)) return false;
      return true;
    });

    var sort = filters.sort.value;
    out.sort(function (a, b) {
      switch (sort) {
        case "added_asc": return a.dateAdded - b.dateAdded;
        case "price_asc": return (a.price || Infinity) - (b.price || Infinity);
        case "price_desc": return (b.price || -1) - (a.price || -1);
        case "area_desc": return (b.area || -1) - (a.area || -1);
        case "rating_desc": return (b.rating || 0) - (a.rating || 0);
        case "priority_desc": return PRIORITY_RANK[b.priority] - PRIORITY_RANK[a.priority];
        default: return b.dateAdded - a.dateAdded;
      }
    });
    return out;
  }

  function buildStars(container, record) {
    container.innerHTML = "";
    for (var i = 1; i <= 5; i++) {
      (function (val) {
        var star = document.createElement("span");
        star.className = "star" + (val <= (record.rating || 0) ? " on" : "");
        star.textContent = "★";
        star.title = val + " / 5";
        star.addEventListener("click", function () {
          record.rating = record.rating === val ? 0 : val;
          saveRecord(record);
          buildStars(container, record);
          if (filters.rating.value !== "0" || filters.sort.value === "rating_desc") render();
        });
        container.appendChild(star);
      })(i);
    }
  }

  function renderCard(record) {
    var node = tpl.content.cloneNode(true);
    var card = node.querySelector(".card");
    card.dataset.id = record.id;
    card.dataset.status = record.status;
    card.dataset.priority = record.priority;

    var imgLink = node.querySelector(".card-img-link");
    var img = node.querySelector(".card-img");
    imgLink.href = record.url;
    img.src = record.image || "";
    img.alt = record.title || "";
    node.querySelector(".site-tag").textContent = record.site || "";
    var kind = listingKind(record);
    var kindEl = node.querySelector(".kind-tag");
    kindEl.textContent = kind === "project" ? "Projekat" : "Stan";
    kindEl.className = "kind-tag kind-" + kind;

    var titleEl = node.querySelector(".card-title");
    titleEl.href = record.url;
    titleEl.textContent = record.title || record.url;

    var facts = node.querySelector(".card-facts");
    var bits = [];
    var isProject = listingKind(record) === "project";
    var showPrice = record.price && (!isProject || record.priceManual);
    var priceHtml;
    if (showPrice) {
      var prefix = record.priceEstimated ? "~ " : "";
      var ttl = record.priceEstimated ? "Procena iz cene po m². Klik za ručni unos." : "Klik za izmenu cene";
      priceHtml = '<span class="price editable" title="' + ttl + '">' + prefix + record.price.toLocaleString("sr-RS") + " €</span>";
    } else {
      priceHtml = '<span class="price editable price-unknown" title="' + missingPriceTitle(record) + '">' + missingPriceLabel(record) + "</span>";
    }
    var vatHtml = "";
    if (record.vat === "without") vatHtml = '<span class="vat vat-without">bez PDV</span>';
    else if (record.vat === "with") vatHtml = '<span class="vat vat-with">sa PDV</span>';
    bits.push('<span class="price-group">' + priceHtml + vatHtml + "</span>");
    var areaLabel;
    if (isProject && record.areaMin != null && record.areaMax != null) areaLabel = record.areaMin + "–" + record.areaMax + " m²";
    else if (record.area) areaLabel = record.area + " m²";
    else if (record.areaMin && record.areaMax) areaLabel = record.areaMin + "–" + record.areaMax + " m²";
    else areaLabel = "+ m²";
    bits.push('<span class="area editable" title="Klik za izmenu kvadrature">' + areaLabel + "</span>");
    var ppm = record.pricePerM2 || (!isProject && record.price && record.area ? Math.round(record.price / record.area) : null);
    if (ppm) bits.push("<span>" + ppm.toLocaleString("sr-RS") + " €/m²</span>");
    if (!isProject && record.rooms != null) bits.push('<span class="bedrooms">' + record.rooms + " spavaće</span>");
    if (record.location) bits.push("<span>" + record.location + "</span>");
    facts.innerHTML = bits.join("");

    var priceEl = facts.querySelector(".price.editable");
    if (priceEl) priceEl.addEventListener("click", function () { editPrice(record); });
    var areaEl = facts.querySelector(".area.editable");
    if (areaEl) areaEl.addEventListener("click", function () { editArea(record); });

    buildStars(node.querySelector(".stars"), record);

    var selPrio = node.querySelector(".sel-priority");
    selPrio.value = record.priority;
    selPrio.dataset.val = record.priority;
    selPrio.addEventListener("change", function () {
      record.priority = selPrio.value;
      selPrio.dataset.val = selPrio.value;
      card.dataset.priority = selPrio.value;
      saveRecord(record);
      if (filters.priority.value || filters.sort.value === "priority_desc") render();
    });

    var selStatus = node.querySelector(".sel-status");
    selStatus.value = record.status;
    selStatus.addEventListener("change", function () {
      record.status = selStatus.value;
      card.dataset.status = selStatus.value;
      if (selStatus.value === "rejected") {
        record.priority = "none";
        selPrio.value = "none";
        selPrio.dataset.val = "none";
        card.dataset.priority = "none";
      }
      saveRecord(record);
      if (filters.status.value || filters.priority.value || filters.sort.value === "priority_desc") render();
    });

    var notes = node.querySelector(".notes");
    var notesSaveBtn = node.querySelector(".notes-save-btn");
    var savedNotes = record.notes || "";

    function syncNotesSaveBtn() {
      var dirty = notes.value !== savedNotes;
      notesSaveBtn.disabled = !dirty;
      notesSaveBtn.classList.remove("saved");
      notesSaveBtn.textContent = "Snimi beleške";
    }

    function saveNotes() {
      if (notes.value === savedNotes) return;
      record.notes = notes.value;
      savedNotes = notes.value;
      saveRecord(record);
      notesSaveBtn.disabled = true;
      notesSaveBtn.classList.add("saved");
      notesSaveBtn.textContent = "Sačuvano";
      card.classList.add("saved-flash");
      setTimeout(function () { card.classList.remove("saved-flash"); }, 800);
    }

    notes.value = savedNotes;
    syncNotesSaveBtn();
    notes.addEventListener("input", syncNotesSaveBtn);
    notes.addEventListener("keydown", function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
        e.preventDefault();
        if (!notesSaveBtn.disabled) saveNotes();
      }
    });
    notesSaveBtn.addEventListener("click", saveNotes);

    node.querySelector(".added-date").textContent = "Dodato " + fmtDate(record.dateAdded);

    node.querySelector(".del-btn").addEventListener("click", function () {
      if (confirm("Obrisati ovu nekretninu iz liste?")) deleteRecord(record.id);
    });

    return node;
  }

  function renderGroupHeading(label, count) {
    var heading = document.createElement("h2");
    heading.className = "group-heading";
    heading.textContent = label;
    var badge = document.createElement("span");
    badge.className = "group-count";
    badge.textContent = String(count);
    heading.appendChild(badge);
    return heading;
  }

  function appendCards(container, records) {
    var frag = document.createDocumentFragment();
    records.forEach(function (r) { frag.appendChild(renderCard(r)); });
    container.appendChild(frag);
  }

  function render() {
    var records = Object.keys(cache).map(function (k) { return cache[k]; });
    populateSiteFilter(records);
    var filtered = applyFilters(records);
    var groupKeywords = parseGroupKeywords(filters.groupKeywords.value);

    grid.innerHTML = "";
    grid.classList.toggle("grouped", groupKeywords.length > 0);
    if (records.length === 0) {
      emptyEl.classList.remove("hidden");
    } else {
      emptyEl.classList.add("hidden");
    }
    resultCount.textContent = filtered.length + " od " + records.length;

    if (!groupKeywords.length) {
      appendCards(grid, filtered);
      return;
    }

    var groups = buildKeywordGroups(filtered, groupKeywords);
    var frag = document.createDocumentFragment();
    groups.forEach(function (group) {
      var block = document.createElement("section");
      block.className = "group-block";
      block.appendChild(renderGroupHeading(group.label, group.records.length));
      var inner = document.createElement("div");
      inner.className = "group-grid";
      appendCards(inner, group.records);
      block.appendChild(inner);
      frag.appendChild(block);
    });
    grid.appendChild(frag);
  }

  function importData(file) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var parsed = JSON.parse(reader.result);
        var incoming = parsed.listings || parsed;
        var added = 0;
        Object.keys(incoming).forEach(function (id) {
          if (!cache[id]) added++;
          cache[id] = incoming[id];
        });
        localWriteDepth++;
        NTStorage.setAll(cache).then(function () {
          chrome.runtime.sendMessage({ type: "REFRESH_BADGE" });
          localWriteDepth--;
          render();
          alert("Uvezeno. Novih: " + added + ".");
        });
      } catch (e) {
        alert("Neispravan JSON fajl.");
      }
    };
    reader.readAsText(file);
  }

  Object.keys(filters).forEach(function (k) {
    var evt = (k === "search" || k === "groupKeywords") ? "input" : "change";
    filters[k].addEventListener(evt, render);
  });

  document.getElementById("import-btn").addEventListener("click", function () {
    document.getElementById("import-file").click();
  });
  document.getElementById("import-file").addEventListener("change", function (e) {
    if (e.target.files[0]) importData(e.target.files[0]);
    e.target.value = "";
  });

  var accountBtn = document.getElementById("account-btn");

  function refreshAccountBtn() {
    if (!accountBtn || typeof NTSupabase === "undefined") return;
    NTSupabase.getStatus().then(function (st) {
      if (st.loggedIn && st.username) {
        accountBtn.textContent = st.username;
        accountBtn.classList.add("logged-in");
        accountBtn.title = "Nalog — ulogovan";
      } else {
        accountBtn.textContent = "Nalog";
        accountBtn.classList.remove("logged-in");
        accountBtn.title = "Prijavi se";
      }
    });
  }

  function autoSync() {
    if (typeof NTStorage === "undefined" || !NTStorage.syncNow) return;
    NTSupabase.getStatus().then(function (st) {
      if (!st.loggedIn) return;
      NTStorage.syncNow().then(function () {
        return getAll();
      }).then(function (map) {
        cache = map;
        render();
        refreshAccountBtn();
      }).catch(function () {});
    });
  }

  if (accountBtn) {
    accountBtn.addEventListener("click", function () {
      if (chrome.runtime.openOptionsPage) {
        chrome.runtime.openOptionsPage();
      } else {
        window.open(chrome.runtime.getURL("options.html"), "_blank");
      }
    });
  }

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== NTStorage.storageArea || !NTStorage.isListingChange(changes)) return;
    if (localWriteDepth > 0) return;
    NTStorage.getAll().then(function (map) {
      cache = map;
      render();
    });
  });

  function focusListingFromHash() {
    var id = (location.hash || "").replace(/^#/, "");
    if (!id) return;
    requestAnimationFrame(function () {
      var card = document.querySelector('.card[data-id="' + CSS.escape(id) + '"]');
      if (!card) return;
      card.scrollIntoView({ behavior: "smooth", block: "center" });
      card.classList.add("saved-flash");
      setTimeout(function () { card.classList.remove("saved-flash"); }, 1200);
    });
  }

  getAll().then(function (map) {
    cache = map;
    render();
    focusListingFromHash();
    refreshAccountBtn();
    autoSync();
  });
})();
