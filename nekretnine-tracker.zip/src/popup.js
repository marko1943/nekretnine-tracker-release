(function () {
  "use strict";

  var saveBtn = document.getElementById("save-btn");
  var openListBtn = document.getElementById("open-list");
  var statusMsg = document.getElementById("status-msg");
  var countEl = document.getElementById("count");
  var current = document.getElementById("current");
  var currentImg = document.getElementById("current-img");
  var currentTitle = document.getElementById("current-title");
  var currentMeta = document.getElementById("current-meta");
  var quickEdit = document.getElementById("quick-edit");
  var quickEditHint = document.getElementById("quick-edit-hint");
  var qePriority = document.getElementById("qe-priority");
  var qeStatus = document.getElementById("qe-status");
  var qeNotes = document.getElementById("qe-notes");
  var qeSave = document.getElementById("qe-save");
  var qeSkip = document.getElementById("qe-skip");

  var activeRecord = null;

  function listingKindLabel(record) {
    if (record.kind === "project") return "Projekat";
    if (record.kind === "stan") return "Stan";
    if (record.areaMin != null && record.areaMax != null) return "Projekat";
    try {
      var p = new URL(record.url).pathname.toLowerCase();
      if (p.indexOf("/novogradnja/") !== -1 || p.indexOf("/a/novogradnja/") !== -1) return "Projekat";
    } catch (e) {}
    return "Stan";
  }

  function fmtPrice(record) {
    if (listingKindLabel(record) === "Projekat" && !record.priceManual) return "Po kvadraturi";
    if (!record.price) {
      return record.areaMin != null && record.areaMax != null ? "Po kvadraturi" : "Cena nepoznata";
    }
    return (record.priceEstimated ? "~ " : "") + record.price.toLocaleString("sr-RS") + " €";
  }

  function isHttpUrl(url) {
    if (!url) return false;
    try {
      var p = new URL(url).protocol;
      return p === "http:" || p === "https:";
    } catch (e) {
      return false;
    }
  }

  function showStatus(text, cls) {
    statusMsg.textContent = text;
    statusMsg.className = "status-msg " + cls;
  }

  function refreshCount() {
    NTStorage.getAll().then(function (map) {
      var n = Object.keys(map).length;
      countEl.textContent = n + " sačuvanih";
    });
  }

  function renderCard(record) {
    current.classList.remove("hidden");
    if (record.image) {
      currentImg.src = record.image;
      currentImg.classList.remove("hidden");
    } else {
      currentImg.classList.add("hidden");
    }
    currentTitle.textContent = record.title || record.url;
    var parts = [record.site, listingKindLabel(record), fmtPrice(record)];
    var isProject = listingKindLabel(record) === "Projekat";
    if (isProject && record.areaMin != null && record.areaMax != null) parts.push(record.areaMin + "–" + record.areaMax + " m²");
    else if (record.area) parts.push(record.area + " m²");
    else if (record.areaMin && record.areaMax) parts.push(record.areaMin + "–" + record.areaMax + " m²");
    var ppm = record.pricePerM2 || (!isProject && record.price && record.area ? Math.round(record.price / record.area) : null);
    if (ppm) parts.push(ppm.toLocaleString("sr-RS") + " €/m²");
    if (record.vat === "without") parts.push("bez PDV");
    else if (record.vat === "with") parts.push("sa PDV");
    currentMeta.textContent = parts.filter(Boolean).join(" · ");
  }

  function hideQuickEdit() {
    quickEdit.classList.add("hidden");
    activeRecord = null;
  }

  function showQuickEdit(record, created) {
    activeRecord = record;
    renderCard(record);
    quickEditHint.textContent = created
      ? "Oglas je sačuvan. Dodaj prioritet, status ili kratku belešku."
      : "Oglas je ažuriran. Po želji izmeni detalje.";
    qePriority.value = record.priority || "none";
    qeStatus.value = record.status || "to_visit";
    qeNotes.value = record.notes || "";
    quickEdit.classList.remove("hidden");
    qeNotes.focus();
  }

  function closePopup() {
    window.close();
  }

  function persistQuickEdit() {
    if (!activeRecord) return;
    activeRecord.priority = qePriority.value;
    activeRecord.status = qeStatus.value;
    activeRecord.notes = qeNotes.value.trim();
    activeRecord.dateUpdated = Date.now();
    qeSave.disabled = true;
    NTStorage.save(activeRecord).then(function () {
      chrome.runtime.sendMessage({ type: "REFRESH_BADGE" });
      closePopup();
    });
  }

  function loadPendingQuickEdit() {
    if (!chrome.storage.session) return;
    chrome.storage.session.get("pendingQuickEdit", function (data) {
      var pending = data && data.pendingQuickEdit;
      if (!pending || !pending.id) return;
      NTStorage.getAll().then(function (map) {
        var record = map[pending.id];
        chrome.storage.session.remove("pendingQuickEdit");
        if (record) {
          showStatus("Sačuvano ✓", "ok");
          showQuickEdit(record, true);
        }
      });
    });
  }

  function finishSave(resp) {
    saveBtn.disabled = false;
    if (!resp || !resp.ok) {
      showStatus(
        resp && resp.reason === "unsupported_url"
          ? "Otvori stranicu oglasa (http/https)."
          : "Nije uspelo. Probaj na stranici oglasa.",
        "err"
      );
      return;
    }
    showStatus(resp.created ? "Sačuvano ✓" : "Ažurirano ✓", "ok");
    showQuickEdit(resp.record, resp.created);
    refreshCount();
  }

  saveBtn.addEventListener("click", function () {
    saveBtn.disabled = true;
    showStatus("Čuvam...", "warn");
    hideQuickEdit();
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs[0];
      if (!tab || !isHttpUrl(tab.url)) {
        saveBtn.disabled = true;
        showStatus("Otvori stranicu oglasa (http/https).", "warn");
        return;
      }
      chrome.runtime.sendMessage({ type: "SAVE_CURRENT_TAB", tab: tab }, function (resp) {
        if (chrome.runtime.lastError) {
          saveBtn.disabled = false;
          showStatus("Nije uspelo. Reload ekstenzije pa probaj ponovo.", "err");
          return;
        }
        finishSave(resp);
      });
    });
  });

  qeSave.addEventListener("click", persistQuickEdit);
  qeSkip.addEventListener("click", closePopup);

  openListBtn.addEventListener("click", function () {
    var url = chrome.runtime.getURL("list.html");
    if (activeRecord && activeRecord.id) url += "#" + activeRecord.id;
    chrome.tabs.create({ url: url });
  });

  refreshCount();
  loadPendingQuickEdit();

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var tab = tabs[0];
    if (!tab || !isHttpUrl(tab.url)) {
      saveBtn.disabled = true;
      showStatus("Otvori stranicu oglasa (http/https).", "warn");
    }
  });
})();
