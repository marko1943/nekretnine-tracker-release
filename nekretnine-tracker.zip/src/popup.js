(function () {
  "use strict";

  var saveBtn = document.getElementById("save-btn");
  var openListBtn = document.getElementById("open-list");
  var statusMsg = document.getElementById("status-msg");
  var countEl = document.getElementById("count");
  var current = document.getElementById("current");
  var currentImg = document.getElementById("current-img");
  var currentTitle = document.getElementById("current-title");
  var currentMeta = document.getElementById("current-meta");

  function listingKindLabel(record) {
    if (record.kind === "project") return "Projekat";
    if (record.kind === "stan") return "Stan";
    if (record.areaMin != null && record.areaMax != null) return "Projekat";
    try {
      var p = new URL(record.url).pathname.toLowerCase();
      if (p.indexOf("/novogradnja/") !== -1 || p.indexOf("/a/novogradnja/") !== -1) return "Projekat";
    } catch (e) {}
    return "Stan";
  }

  function fmtPrice(record) {
    if (listingKindLabel(record) === "Projekat" && !record.priceManual) return "Po kvadraturi";
    if (!record.price) {
      return record.areaMin != null && record.areaMax != null ? "Po kvadraturi" : "Cena nepoznata";
    }
    return (record.priceEstimated ? "~ " : "") + record.price.toLocaleString("sr-RS") + " €";
  }

  function isHttpUrl(url) {
    if (!url) return false;
    try {
      var p = new URL(url).protocol;
      return p === "http:" || p === "https:";
    } catch (e) {
      return false;
    }
  }

  function showStatus(text, cls) {
    statusMsg.textContent = text;
    statusMsg.className = "status-msg " + cls;
  }

  function refreshCount() {
    NTStorage.getAll().then(function (map) {
      var n = Object.keys(map).length;
      countEl.textContent = n + " sačuvanih";
    });
  }

  function renderCard(record) {
    current.classList.remove("hidden");
    if (record.image) {
      currentImg.src = record.image;
      currentImg.classList.remove("hidden");
    } else {
      currentImg.classList.add("hidden");
    }
    currentTitle.textContent = record.title || record.url;
    var parts = [record.site, listingKindLabel(record), fmtPrice(record)];
    var isProject = listingKindLabel(record) === "Projekat";
    if (isProject && record.areaMin != null && record.areaMax != null) parts.push(record.areaMin + "–" + record.areaMax + " m²");
    else if (record.area) parts.push(record.area + " m²");
    else if (record.areaMin && record.areaMax) parts.push(record.areaMin + "–" + record.areaMax + " m²");
    var ppm = record.pricePerM2 || (!isProject && record.price && record.area ? Math.round(record.price / record.area) : null);
    if (ppm) parts.push(ppm.toLocaleString("sr-RS") + " €/m²");
    if (record.vat === "without") parts.push("bez PDV");
    else if (record.vat === "with") parts.push("sa PDV");
    currentMeta.textContent = parts.filter(Boolean).join(" · ");
  }

  saveBtn.addEventListener("click", function () {
    saveBtn.disabled = true;
    showStatus("Čuvam...", "warn");
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs[0];
      chrome.runtime.sendMessage({ type: "SAVE_CURRENT_TAB", tab: tab }, function (resp) {
        saveBtn.disabled = !tab || !isHttpUrl(tab.url);
        if (!resp || !resp.ok) {
          showStatus(
            resp && resp.reason === "unsupported_url"
              ? "Otvori stranicu oglasa (http/https)."
              : "Nije uspelo. Probaj na stranici oglasa.",
            "err"
          );
          return;
        }
        showStatus(resp.created ? "Sačuvano ✓" : "Ažurirano ✓", "ok");
        renderCard(resp.record);
        refreshCount();
      });
    });
  });

  openListBtn.addEventListener("click", function () {
    chrome.tabs.create({ url: chrome.runtime.getURL("list.html") });
  });

  refreshCount();

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var tab = tabs[0];
    if (!tab || !isHttpUrl(tab.url)) {
      saveBtn.disabled = true;
      showStatus("Otvori stranicu oglasa (http/https).", "warn");
    }
  });
})();
