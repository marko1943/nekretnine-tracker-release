// Content skripta: na zahtev pozadine/popup-a izvlači podatke sa otvorene stranice.
(function () {
  "use strict";

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg && msg.type === "SCRAPE_CURRENT") {
      try {
        var data = self.NS.scrapeDocument(document, location.href);
        sendResponse({ ok: true, data: data });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
      return true;
    }
  });
})();
