// Čista merge logika local ↔ remote (testabilno u Node-u).
(function (global) {
  "use strict";

  function updatedAt(record) {
    if (!record) return 0;
    return Number(record.dateUpdated || record.dateAdded || 0) || 0;
  }

  /**
   * Spaja lokalnu mapu sa remote redovima.
   * remoteRows: [{ id, payload, updated_at, deleted }]
   * Vraća: { map, push, changed }
   *  - map: nova lokalna mapa (bez obrisanih)
   *  - push: zapisi koje treba upsert-ovati na server (uključujući soft-delete)
   *  - changed: da li se lokalna mapa razlikuje od ulaza
   */
  function mergeMaps(localMap, remoteRows) {
    localMap = localMap || {};
    remoteRows = remoteRows || [];

    var remoteById = {};
    remoteRows.forEach(function (row) {
      if (row && row.id) remoteById[row.id] = row;
    });

    var map = {};
    var push = [];
    var changed = false;
    var seen = {};

    Object.keys(localMap).forEach(function (id) {
      seen[id] = true;
      var local = localMap[id];
      var remote = remoteById[id];

      if (!remote) {
        map[id] = local;
        push.push({ id: id, payload: local, updated_at: updatedAt(local), deleted: false });
        return;
      }

      if (remote.deleted) {
        if (updatedAt(local) > Number(remote.updated_at || 0)) {
          map[id] = local;
          push.push({ id: id, payload: local, updated_at: updatedAt(local), deleted: false });
        } else {
          changed = true;
        }
        return;
      }

      var remotePayload = remote.payload || {};
      var localTs = updatedAt(local);
      var remoteTs = Number(remote.updated_at || updatedAt(remotePayload) || 0);

      if (remoteTs > localTs) {
        map[id] = remotePayload;
        if (JSON.stringify(remotePayload) !== JSON.stringify(local)) changed = true;
      } else if (localTs > remoteTs) {
        map[id] = local;
        push.push({ id: id, payload: local, updated_at: localTs, deleted: false });
      } else {
        map[id] = local;
      }
    });

    Object.keys(remoteById).forEach(function (id) {
      if (seen[id]) return;
      var remote = remoteById[id];
      if (remote.deleted) return;
      var payload = remote.payload;
      if (!payload) return;
      map[id] = payload;
      changed = true;
    });

    if (!changed) {
      var localIds = Object.keys(localMap).sort();
      var newIds = Object.keys(map).sort();
      if (localIds.length !== newIds.length) changed = true;
      else {
        for (var i = 0; i < localIds.length; i++) {
          if (localIds[i] !== newIds[i]) {
            changed = true;
            break;
          }
        }
      }
    }

    return { map: map, push: push, changed: changed };
  }

  var api = { mergeMaps: mergeMaps, updatedAt: updatedAt };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
  global.NTSyncMerge = api;
})(typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : this);
