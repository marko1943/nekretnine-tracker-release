// Supabase projekat — publishable key je javan, može u git / ZIP.
(function (global) {
  "use strict";

  global.NTApiConfig = {
    supabaseUrl: "https://hnajhnkgstpzbvcpumjk.supabase.co",
    supabaseKey: "sb_publishable_tsUVQ3bMUs1CQq7Ia_tuow_evbSL_qf"
  };
})(typeof self !== "undefined" ? self : window);
