// Javni URL tvog API-ja (Cloudflare Worker). Nije secret — može u git / ZIP.
// Posle `cd server && npx wrangler deploy` ubaci workers.dev URL.
(function (global) {
  "use strict";

  global.NTApiConfig = {
    apiUrl: ""
  };
})(typeof self !== "undefined" ? self : window);
