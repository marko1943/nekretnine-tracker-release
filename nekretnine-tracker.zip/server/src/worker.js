/**
 * Tanak API ispred Supabase-a.
 * Ekstenzija vidi samo ovaj origin — SUPABASE_* ostaju secret na Workeru.
 */

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Max-Age": "86400"
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS }
  });
}

function err(message, status = 400, code) {
  return json({ error: message, code: code || undefined }, status);
}

function toAuthEmail(username) {
  const u = String(username || "").trim();
  if (!u) return "";
  if (u.includes("@")) return u;
  const safe = u.toLowerCase().replace(/[^a-z0-9._-]+/g, "");
  return safe ? `${safe}@nekretnine.local` : "";
}

function displayName(username, user) {
  if (username) return String(username).trim();
  const meta = user && user.user_metadata && user.user_metadata.username;
  if (meta) return meta;
  const email = user && user.email ? user.email : "";
  if (email.endsWith("@nekretnine.local")) return email.split("@")[0];
  return email;
}

function sessionPayload(data, username) {
  if (!data || !data.access_token) return null;
  const user = data.user || null;
  return {
    access_token: data.access_token,
    refresh_token: data.refresh_token || "",
    expires_at: data.expires_at || Math.floor(Date.now() / 1000) + (data.expires_in || 3600),
    user,
    username: displayName(username, user)
  };
}

async function readJson(request) {
  try {
    return await request.json();
  } catch {
    return null;
  }
}

function requireEnv(env) {
  if (!env.SUPABASE_URL || !env.SUPABASE_ANON_KEY) {
    return err("Server nije konfigurisan (SUPABASE_URL / SUPABASE_ANON_KEY)", 500, "server_misconfigured");
  }
  return null;
}

function sbHeaders(env, accessToken) {
  return {
    apikey: env.SUPABASE_ANON_KEY,
    "Content-Type": "application/json",
    Authorization: `Bearer ${accessToken || env.SUPABASE_ANON_KEY}`
  };
}

async function sbFetch(env, path, options = {}) {
  const res = await fetch(`${env.SUPABASE_URL.replace(/\/+$/, "")}${path}`, {
    method: options.method || "GET",
    headers: sbHeaders(env, options.accessToken),
    body: options.body != null ? JSON.stringify(options.body) : undefined
  });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { raw: text };
  }
  return { res, data, text };
}

function bearer(request) {
  const h = request.headers.get("Authorization") || "";
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return m ? m[1].trim() : "";
}

async function handleRegister(request, env) {
  const body = await readJson(request);
  const username = body && body.username;
  const password = body && body.password;
  const email = toAuthEmail(username);
  if (!email || !password) return err("Username i lozinka su obavezni", 400, "bad_request");

  const { res, data } = await sbFetch(env, "/auth/v1/signup", {
    method: "POST",
    body: {
      email,
      password: String(password),
      data: { username: String(username).trim() }
    }
  });

  if (!res.ok) {
    return err(
      (data && (data.msg || data.message || data.error_description || data.error)) || "Registracija nije uspela",
      res.status,
      "signup_failed"
    );
  }

  const session = sessionPayload(data, username);
  if (!session) {
    return json({ ok: true, needsConfirm: true, session: null });
  }
  return json({ ok: true, needsConfirm: false, session });
}

async function handleLogin(request, env) {
  const body = await readJson(request);
  const username = body && body.username;
  const password = body && body.password;
  const email = toAuthEmail(username);
  if (!email || !password) return err("Username i lozinka su obavezni", 400, "bad_request");

  const { res, data } = await sbFetch(env, "/auth/v1/token?grant_type=password", {
    method: "POST",
    body: { email, password: String(password) }
  });

  if (!res.ok) {
    return err(
      (data && (data.error_description || data.msg || data.message || data.error)) || "Prijava nije uspela",
      res.status,
      "login_failed"
    );
  }

  return json({ ok: true, session: sessionPayload(data, username) });
}

async function handleRefresh(request, env) {
  const body = await readJson(request);
  const refresh = body && body.refresh_token;
  if (!refresh) return err("Nedostaje refresh_token", 400, "bad_request");

  const { res, data } = await sbFetch(env, "/auth/v1/token?grant_type=refresh_token", {
    method: "POST",
    body: { refresh_token: refresh }
  });

  if (!res.ok) {
    return err(
      (data && (data.error_description || data.message || data.error)) || "Refresh nije uspeo",
      res.status,
      "refresh_failed"
    );
  }

  return json({ ok: true, session: sessionPayload(data, null) });
}

async function handleLogout(request, env) {
  const token = bearer(request);
  if (token) {
    await sbFetch(env, "/auth/v1/logout", {
      method: "POST",
      accessToken: token,
      body: {}
    });
  }
  return json({ ok: true });
}

async function handleListingsGet(request, env) {
  const token = bearer(request);
  if (!token) return err("Nisi ulogovan", 401, "not_logged_in");

  const { res, data } = await sbFetch(
    env,
    "/rest/v1/listings?select=id,payload,updated_at,deleted&order=updated_at.asc",
    { method: "GET", accessToken: token }
  );

  if (!res.ok) {
    return err(
      (data && (data.message || data.error)) || "Čitanje liste nije uspelo",
      res.status,
      "listings_get_failed"
    );
  }
  return json({ ok: true, rows: data || [] });
}

async function handleListingsUpsert(request, env) {
  const token = bearer(request);
  if (!token) return err("Nisi ulogovan", 401, "not_logged_in");

  const body = await readJson(request);
  const rows = (body && body.rows) || [];
  if (!Array.isArray(rows) || !rows.length) return json({ ok: true });

  const userRes = await sbFetch(env, "/auth/v1/user", {
    method: "GET",
    accessToken: token
  });
  if (!userRes.res.ok || !userRes.data || !userRes.data.id) {
    return err("Sesija nije važeća", 401, "not_logged_in");
  }
  const userId = userRes.data.id;

  const payload = rows.map((r) => ({
    user_id: userId,
    id: r.id,
    payload: r.payload,
    updated_at: r.updated_at,
    deleted: !!r.deleted
  }));

  const url = `${env.SUPABASE_URL.replace(/\/+$/, "")}/rest/v1/listings?on_conflict=user_id,id`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      ...sbHeaders(env, token),
      Prefer: "resolution=merge-duplicates,return=minimal"
    },
    body: JSON.stringify(payload)
  });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }

  if (!res.ok) {
    return err(
      (data && (data.message || data.error)) || text || "Upis nije uspeo",
      res.status,
      "listings_upsert_failed"
    );
  }
  return json({ ok: true });
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS });
    }

    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";

    if (path === "/health") {
      return json({ ok: true, service: "nekretnine-tracker-api" });
    }

    const mis = requireEnv(env);
    if (mis) return mis;

    try {
      if (path === "/auth/register" && request.method === "POST") return handleRegister(request, env);
      if (path === "/auth/login" && request.method === "POST") return handleLogin(request, env);
      if (path === "/auth/refresh" && request.method === "POST") return handleRefresh(request, env);
      if (path === "/auth/logout" && request.method === "POST") return handleLogout(request, env);
      if (path === "/listings" && request.method === "GET") return handleListingsGet(request, env);
      if (path === "/listings/upsert" && request.method === "POST") return handleListingsUpsert(request, env);
      return err("Not found", 404, "not_found");
    } catch (e) {
      return err(e && e.message ? e.message : "Server error", 500, "server_error");
    }
  }
};
