# Nekretnine Tracker API

Cloudflare Worker ispred Supabase-a. Ekstenzija zove **samo** ovaj API — `SUPABASE_URL` / `SUPABASE_ANON_KEY` su secret na Workeru, ne u ZIP-u.

## Setup

```bash
cd server
npm install
npx wrangler login
npx wrangler secret put SUPABASE_URL      # https://xxxx.supabase.co
npx wrangler secret put SUPABASE_ANON_KEY # anon public key
npx wrangler deploy
```

URL koji dobiješ (npr. `https://nekretnine-tracker-api.<nalog>.workers.dev`) ubaci u `src/api-config.js` u root repou ekstenzije.

Supabase: pokreni `docs/supabase.sql`, Email auth ON, **Confirm email OFF**.

## Lokalno

```bash
# server/.dev.vars
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_ANON_KEY=eyJ...

npm run dev
```

## Rute

| Method | Path | Auth |
|--------|------|------|
| GET | `/health` | ne |
| POST | `/auth/register` | ne — `{ username, password }` |
| POST | `/auth/login` | ne — `{ username, password }` |
| POST | `/auth/refresh` | ne — `{ refresh_token }` |
| POST | `/auth/logout` | Bearer |
| GET | `/listings` | Bearer |
| POST | `/listings/upsert` | Bearer — `{ rows: [...] }` |
